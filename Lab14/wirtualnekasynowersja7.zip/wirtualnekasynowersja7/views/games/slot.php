<?php use App\Core\Csrf; ?>
<div class="page-header">
  <span class="eyebrow">Gra</span>
  <h1>Jednoręki bandyta</h1>
  <p class="lead">Trzy takie same symbole dają największą wygraną, dwa takie same — pocieszenie. Twoje saldo: <strong style="color:var(--accent-soft);"><?= money((float) $user['balance']) ?></strong></p>
</div>

<div class="roulette-wrap">
  <div class="slot-machine">
    <?php $reels = $lastResult['reels'] ?? ['🍒', '🍋', '🔔']; ?>
    <div class="reel" id="reel-0"><?= e($reels[0]) ?></div>
    <div class="reel" id="reel-1"><?= e($reels[1]) ?></div>
    <div class="reel" id="reel-2"><?= e($reels[2]) ?></div>
  </div>
  <?php if ($lastResult): ?>
    <script>
      ['reel-0', 'reel-1', 'reel-2'].forEach(function (id) {
        document.getElementById(id).textContent = '🎰';
      });
    </script>
  <?php endif; ?>

  <div class="card" style="min-width:320px;max-width:420px;">
    <?php if ($lastResult): ?>
      <div id="drawing-indicator">
        <div class="card-title">🎰 Bębny się kręcą...</div>
        <p class="muted">Losowanie w toku, chwila cierpliwości.</p>
        <hr class="divider">
      </div>

      <div id="result-panel" style="display:none;">
        <div class="card-title">Ostatni wynik</div>
        <p class="muted">Zakład: <?= money((float) $lastResult['bet_amount']) ?></p>
        <p>
          <?php if ($lastResult['win']): ?>
            <span class="badge badge-active">Wygrana: <?= money((float) $lastResult['win_amount']) ?></span>
          <?php else: ?>
            <span class="badge badge-inactive">Przegrana</span>
          <?php endif; ?>
        </p>
        <hr class="divider">
      </div>

      <noscript>
        <style>#drawing-indicator{display:none!important;}#result-panel{display:block!important;}</style>
      </noscript>
    <?php endif; ?>

    <form method="post" action="<?= base_url('slot.php') ?>" novalidate>
      <?= Csrf::field() ?>

      <div class="form-group">
        <label for="bet_amount">Kwota zakładu</label>
        <input type="number" id="bet_amount" name="bet_amount" min="1" step="0.01" value="<?= e($old['bet_amount']) ?>" class="<?= isset($errors['bet_amount']) ? 'is-invalid' : '' ?>">
        <?php if (isset($errors['bet_amount'])): ?><div class="field-error"><?= e($errors['bet_amount']) ?></div><?php endif; ?>
      </div>

      <button type="submit" class="btn btn-primary btn-block" id="slot-submit">Zakręć bębnami</button>
    </form>

    <p class="hint" style="margin-top:14px;">
      Tabela wygranych za 3 symbole: 🍒 ×3 · 🍋 ×5 · 🔔 ×10 · ⭐ ×20 · 💎 ×50 · 7️⃣ ×100. Para takich samych symboli zwraca stawkę.
    </p>
  </div>
</div>

<?php if ($lastResult): ?>
<script>
// Po zakręceniu wynik jest już znany (obliczony po stronie serwera), ale celowo
// pokazujemy najpierw animację kręcących się bębnów, a komunikat o wygranej/przegranej
// dopiero po jej zakończeniu - zamiast natychmiastowego ujawnienia.
(function () {
  var reelEls = [document.getElementById('reel-0'), document.getElementById('reel-1'), document.getElementById('reel-2')];
  var symbolsPool = ['🍒', '🍋', '🔔', '⭐', '💎', '7️⃣'];
  var finalReels = <?= json_encode($lastResult['reels'], JSON_HEX_TAG | JSON_HEX_AMP) ?>;
  var drawingIndicator = document.getElementById('drawing-indicator');
  var resultPanel = document.getElementById('result-panel');
  var flashArea = document.getElementById('flash-area');
  var submitBtn = document.getElementById('slot-submit');
  var SPIN_DURATION = 1500;
  var TICK = 90;

  if (flashArea) flashArea.style.display = 'none';
  if (submitBtn) submitBtn.disabled = true;
  reelEls.forEach(function (el) { if (el) el.classList.add('spinning'); });

  var tickTimer = window.setInterval(function () {
    reelEls.forEach(function (el) {
      if (el) el.textContent = symbolsPool[Math.floor(Math.random() * symbolsPool.length)];
    });
  }, TICK);

  window.setTimeout(function () {
    window.clearInterval(tickTimer);
    reelEls.forEach(function (el, i) {
      if (!el) return;
      el.textContent = finalReels[i];
      el.classList.remove('spinning');
    });
    if (drawingIndicator) drawingIndicator.style.display = 'none';
    if (resultPanel) resultPanel.style.display = '';
    if (flashArea) flashArea.style.display = '';
    if (submitBtn) submitBtn.disabled = false;
  }, SPIN_DURATION);
})();
</script>
<?php endif; ?>

