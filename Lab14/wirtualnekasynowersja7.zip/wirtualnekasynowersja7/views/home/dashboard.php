<div class="page-header">
  <span class="eyebrow">Lobby</span>
  <h1>Witaj, <?= e($user['name']) ?>!</h1>
  <p class="lead">Twoje saldo: <strong style="color:var(--accent-soft);"><?= money((float) $user['balance']) ?></strong>. Wybierz grę albo sprawdź aktualne promocje.</p>
</div>

<div class="grid grid-3">
  <a class="card tile" href="<?= base_url('roulette.php') ?>" style="text-decoration:none;">
    <span class="tile-icon"><span class="brand-wheel tile-icon-wheel" aria-hidden="true"></span></span>
    <h3 style="color:var(--accent-soft);">Ruletka</h3>
    <p class="muted">Postaw na liczbę, kolor lub parzystość.</p>
    <span class="tile-arrow">Zagraj →</span>
  </a>
  <a class="card tile" href="<?= base_url('slot.php') ?>" style="text-decoration:none;">
    <span class="tile-icon">🎰</span>
    <h3 style="color:var(--accent-soft);">Jednoręki bandyta</h3>
    <p class="muted">Zakręć bębnami i szukaj trzech takich samych symboli.</p>
    <span class="tile-arrow">Zagraj →</span>
  </a>
  <a class="card tile" href="<?= base_url('promotions.php') ?>" style="text-decoration:none;">
    <span class="tile-icon">🎁</span>
    <h3 style="color:var(--accent-soft);">Promocje</h3>
    <p class="muted">Przystąp do programu lojalnościowego i odbieraj bonusy.</p>
    <span class="tile-arrow">Zobacz →</span>
  </a>
</div>

<div class="grid grid-2" style="margin-top:28px;align-items:start;">
  <div class="card">
    <div class="card-title">Ostatnie rozgrywki</div>
    <?php if (empty($recentBets)): ?>
      <p class="muted">Nie zagrałeś jeszcze żadnej gry. Spróbuj swoich sił!</p>
    <?php else: ?>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Gra</th><th>Stawka</th><th>Wynik</th><th>Wygrana</th><th>Data</th></tr></thead>
          <tbody>
          <?php foreach ($recentBets as $bet): ?>
            <tr>
              <td><?= $bet['game_type'] === 'roulette' ? 'Ruletka' : 'Jednoręki bandyta' ?></td>
              <td><?= money((float) $bet['bet_amount']) ?></td>
              <td><span class="badge <?= $bet['result'] === 'win' ? 'badge-active' : 'badge-inactive' ?>"><?= $bet['result'] === 'win' ? 'Wygrana' : 'Przegrana' ?></span></td>
              <td><?= money((float) $bet['win_amount']) ?></td>
              <td class="muted"><?= e(date('d.m.Y H:i', strtotime($bet['created_at']))) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="card-title">Aktualne promocje</div>
    <?php if (empty($activePromotions)): ?>
      <p class="muted">Obecnie nie ma aktywnych promocji.</p>
    <?php else: ?>
      <?php foreach ($activePromotions as $promo): ?>
        <div style="margin-bottom:14px;padding-bottom:14px;border-bottom:1px solid var(--border);">
          <strong style="color:var(--accent-soft);"><?= e($promo['title']) ?></strong>
          <span class="badge badge-active" style="margin-left:8px;">+<?= (int) $promo['bonus_percent'] ?>%</span>
          <p class="muted" style="margin:6px 0 0;font-size:.85rem;">Ważna do <?= e(date('d.m.Y', strtotime($promo['valid_to']))) ?></p>
        </div>
      <?php endforeach; ?>
      <a href="<?= base_url('promotions.php') ?>" class="btn btn-secondary btn-sm">Zobacz wszystkie</a>
    <?php endif; ?>
  </div>
</div>
