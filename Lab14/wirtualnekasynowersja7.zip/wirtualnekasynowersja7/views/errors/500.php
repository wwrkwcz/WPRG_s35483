<?php
/**
 * views/errors/500.php
 *
 * Strona błędu wewnętrznego serwera. Celowo NIE korzysta z header.php
 * ani z klas wymagających bazy danych - błąd mógł właśnie zostać
 * wywołany przez niedostępną bazę danych, więc strona błędu musi
 * być w 100% niezależna, aby nie wywołać kolejnego wyjątku.
 */
$base = function_exists('base_url') ? base_url('') : '/';
?>
<!doctype html>
<html lang="pl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>500 — błąd serwera</title>
<link rel="stylesheet" href="<?= htmlspecialchars(rtrim($base, '/') . '/public/css/style.css', ENT_QUOTES) ?>">
</head>
<body>
<main class="page">
  <div class="container">
    <div class="empty-state card" style="max-width:560px;margin:60px auto;text-align:center;">
      <h1 style="color:var(--red-soft);font-size:3rem;margin-bottom:4px;">500</h1>
      <p class="lead" style="margin:0 auto 18px;">Wystąpił błąd wewnętrzny serwera. Spróbuj ponownie za chwilę. Jeśli problem się powtarza, sprawdź czy MySQL jest uruchomiony i czy dane w <code>config.php</code> są poprawne.</p>
      <a class="btn btn-primary" href="<?= htmlspecialchars(rtrim($base, '/') . '/index.php', ENT_QUOTES) ?>">Wróć do strony głównej</a>
    </div>
  </div>
</main>
</body>
</html>
