  </div>
</main>
<footer class="footer">
  <div>Konto testowe: gracz@kasyno.pl / gracz123</div>
  <div>Konto administratora: admin@kasyno.pl / admin123</div>
</footer>
</body>
</html>
