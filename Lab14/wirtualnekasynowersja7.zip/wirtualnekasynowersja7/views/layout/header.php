<?php
/**
 * views/layout/header.php
 *
 * Wspólny nagłówek HTML + górne menu nawigacyjne.
 * Czysty widok — nie wykonuje żadnych zapytań do bazy danych,
 * korzysta jedynie z danych przygotowanych wcześniej przez skrypt strony
 * (Auth::user(), Flash::pull()).
 */

use App\Core\Auth;
use App\Core\Flash;

$currentUser = Auth::user();
$theme = $currentUser['theme'] ?? 'dark';
$pageTitle = $pageTitle ?? $GLOBALS['config']['app_name'];
$currentScript = basename($_SERVER['SCRIPT_NAME']);
?>
<!doctype html>
<html lang="pl" data-theme="<?= e($theme) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?> — <?= e($GLOBALS['config']['app_name']) ?></title>
<link rel="stylesheet" href="<?= asset('public/css/style.css') ?>">
</head>
<body>
<header class="navbar">
  <div class="navbar-inner">
    <a class="brand" href="<?= base_url('index.php') ?>">
      <span class="brand-wheel" aria-hidden="true"></span>
      Wirtualne Kasyno
    </a>
    <nav class="nav-links">
      <?php if ($currentUser): ?>
        <a href="<?= base_url('index.php') ?>" class="<?= $currentScript === 'index.php' ? 'active' : '' ?>">Start</a>
        <a href="<?= base_url('promotions.php') ?>" class="<?= $currentScript === 'promotions.php' ? 'active' : '' ?>">Promocje</a>
        <a href="<?= base_url('roulette.php') ?>" class="<?= $currentScript === 'roulette.php' ? 'active' : '' ?>">Ruletka</a>
        <a href="<?= base_url('slot.php') ?>" class="<?= $currentScript === 'slot.php' ? 'active' : '' ?>">Jednoręki bandyta</a>
        <a href="<?= base_url('account.php') ?>" class="<?= $currentScript === 'account.php' ? 'active' : '' ?>">Moje konto</a>
        <?php if ($currentUser['role'] === 'admin'): ?>
          <a href="<?= base_url('admin/index.php') ?>" class="<?= str_contains($_SERVER['SCRIPT_NAME'], '/admin/') ? 'active' : '' ?>">Panel admina</a>
        <?php endif; ?>
      <?php endif; ?>
    </nav>
    <div class="nav-right">
      <?php if ($currentUser): ?>
        <span class="balance-pill">💰 <?= money((float) $currentUser['balance']) ?></span>
        <a href="<?= base_url('logout.php') ?>" class="btn btn-secondary btn-sm">Wyloguj</a>
      <?php else: ?>
        <a href="<?= base_url('login.php') ?>" class="btn btn-secondary btn-sm">Zaloguj się</a>
        <a href="<?= base_url('register.php') ?>" class="btn btn-primary btn-sm">Zarejestruj się</a>
      <?php endif; ?>
    </div>
  </div>
</header>
<main class="page">
  <div class="container">
    <div id="flash-area"<?= !empty($deferFlash) ? ' style="display:none"' : '' ?>>
      <?php foreach (Flash::pull() as $type => $message): ?>
        <div class="alert alert-<?= e($type) ?>"><?= e($message) ?></div>
      <?php endforeach; ?>
    </div>
    <?php if (!empty($deferFlash)): ?>
      <noscript><style>#flash-area{display:block!important;}</style></noscript>
    <?php endif; ?>
