<?php use App\Core\Csrf; ?>
<div class="page-header">
  <span class="eyebrow">Profil</span>
  <h1>Moje konto</h1>
  <p class="lead">Dane konta, statystyki gry oraz preferencje wyświetlania.</p>
</div>

<div class="grid grid-4">
  <div class="stat-card">
    <div class="stat-value"><?= money((float) $user['balance']) ?></div>
    <div class="stat-label">Saldo</div>
  </div>
  <div class="stat-card">
    <div class="stat-value"><?= (int) $stats['bets_count'] ?></div>
    <div class="stat-label">Rozegranych zakładów</div>
  </div>
  <div class="stat-card">
    <div class="stat-value"><?= money((float) $stats['total_wagered']) ?></div>
    <div class="stat-label">Suma obstawiona</div>
  </div>
  <div class="stat-card">
    <div class="stat-value" style="color:<?= $stats['net_result'] >= 0 ? 'var(--green-win)' : 'var(--red-soft)' ?>;">
      <?= $stats['net_result'] >= 0 ? '+' : '' ?><?= money((float) $stats['net_result']) ?>
    </div>
    <div class="stat-label">Wynik netto</div>
  </div>
</div>

<div class="grid grid-2" style="margin-top:24px;align-items:start;">
  <div class="card">
    <div class="card-title">Dane konta</div>
    <p><strong>Imię i nazwisko:</strong> <?= e($user['name'] . ' ' . $user['surname']) ?></p>
    <p><strong>E-mail:</strong> <?= e($user['email']) ?></p>
    <p><strong>Rola:</strong> <span class="badge <?= $user['role'] === 'admin' ? 'badge-admin' : 'badge-user' ?>"><?= $user['role'] === 'admin' ? 'Administrator' : 'Użytkownik' ?></span></p>
    <p class="muted" style="margin-bottom:0;">Konto utworzone: <?= e(date('d.m.Y', strtotime($user['created_at']))) ?></p>

    <hr class="divider">

    <div class="card-title">Preferencje</div>
    <form method="post" action="<?= base_url('account.php') ?>">
      <?= Csrf::field() ?>
      <div class="form-group">
        <label for="theme">Motyw wyświetlania</label>
        <select id="theme" name="theme">
          <option value="dark" <?= $user['theme'] === 'dark' ? 'selected' : '' ?>>Ciemny (kasyno)</option>
          <option value="light" <?= $user['theme'] === 'light' ? 'selected' : '' ?>>Jasny</option>
        </select>
        <div class="hint">Wybrany motyw jest zapamiętywany między wizytami.</div>
      </div>
      <button type="submit" class="btn btn-secondary">Zapisz preferencje</button>
    </form>
  </div>

  <div class="card">
    <div class="card-title">Moje promocje</div>
    <?php if (empty($joinedPromotions)): ?>
      <p class="muted">Nie przystąpiłeś jeszcze do żadnej promocji.</p>
      <a href="<?= base_url('promotions.php') ?>" class="btn btn-secondary btn-sm">Zobacz promocje</a>
    <?php else: ?>
      <?php foreach ($joinedPromotions as $promo): ?>
        <div style="margin-bottom:12px;padding-bottom:12px;border-bottom:1px solid var(--border);">
          <strong style="color:var(--accent-soft);"><?= e($promo['title']) ?></strong>
          <span class="badge badge-active" style="margin-left:8px;">+<?= (int) $promo['bonus_percent'] ?>%</span>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>

<div class="card" style="margin-top:24px;">
  <div class="card-title">Historia rozgrywek</div>
  <?php if (empty($recentBets)): ?>
    <p class="muted">Brak rozegranych gier.</p>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Gra</th><th>Szczegóły</th><th>Stawka</th><th>Wynik</th><th>Wygrana</th><th>Saldo po grze</th><th>Data</th></tr></thead>
        <tbody>
        <?php foreach ($recentBets as $bet): ?>
          <tr>
            <td><?= $bet['game_type'] === 'roulette' ? 'Ruletka' : 'Jednoręki bandyta' ?></td>
            <td class="muted"><?= e($bet['bet_details']) ?></td>
            <td><?= money((float) $bet['bet_amount']) ?></td>
            <td><span class="badge <?= $bet['result'] === 'win' ? 'badge-active' : 'badge-inactive' ?>"><?= $bet['result'] === 'win' ? 'Wygrana' : 'Przegrana' ?></span></td>
            <td><?= money((float) $bet['win_amount']) ?></td>
            <td><?= money((float) $bet['balance_after']) ?></td>
            <td class="muted"><?= e(date('d.m.Y H:i', strtotime($bet['created_at']))) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
