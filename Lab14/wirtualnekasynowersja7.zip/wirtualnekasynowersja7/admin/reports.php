<?php

declare(strict_types=1);

require __DIR__ . '/../app/bootstrap.php';

use App\Core\Auth;
use App\Core\Validator;
use App\Models\Bet;

Auth::requireAdmin();

$dateFrom = (string) ($_GET['date_from'] ?? date('Y-m-d', strtotime('-30 days')));
$dateTo = (string) ($_GET['date_to'] ?? date('Y-m-d'));

$validator = new Validator(['date_from' => $dateFrom, 'date_to' => $dateTo]);
$validator->required('date_from', 'Data początku')->date('date_from', 'Data początku');
$validator->required('date_to', 'Data końca')->date('date_to', 'Data końca');
$validator->dateAfterOrEqual('date_to', 'date_from', 'Data końca');

if ($validator->fails()) {
    // Nieprawidłowy zakres dat - wracamy do bezpiecznych wartości domyślnych.
    $dateFrom = date('Y-m-d', strtotime('-30 days'));
    $dateTo = date('Y-m-d');
}

$betModel = new Bet();
$statsByGame = $betModel->statsByGame($dateFrom, $dateTo);
$totals = $betModel->totals($dateFrom, $dateTo);
$registrations = $betModel->registrationsByDay($dateFrom, $dateTo);

$maxRegistrations = 1;
foreach ($registrations as $row) {
    $maxRegistrations = max($maxRegistrations, (int) $row['count']);
}

$gameLabels = ['roulette' => 'Ruletka', 'slot' => 'Jednoręki bandyta'];

$pageTitle = 'Raporty — panel administratora';
require BASE_PATH . '/views/layout/header.php';
require BASE_PATH . '/views/admin/reports.php';
require BASE_PATH . '/views/layout/footer.php';
