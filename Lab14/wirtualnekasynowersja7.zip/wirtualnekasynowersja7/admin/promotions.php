<?php

declare(strict_types=1);

require __DIR__ . '/../app/bootstrap.php';

use App\Core\Auth;
use App\Core\Paginator;
use App\Models\Promotion;
use App\Models\UserPromotion;

Auth::requireAdmin();

$filters = [
    'q'         => trim((string) ($_GET['q'] ?? '')),
    'status'    => (string) ($_GET['status'] ?? ''),
    'date_from' => (string) ($_GET['date_from'] ?? ''),
    'date_to'   => (string) ($_GET['date_to'] ?? ''),
    'bonus_min' => (string) ($_GET['bonus_min'] ?? ''),
    'bonus_max' => (string) ($_GET['bonus_max'] ?? ''),
    'sort'      => (string) ($_GET['sort'] ?? 'created_at'),
    'dir'       => (string) ($_GET['dir'] ?? 'desc'),
];

$page = max(1, (int) ($_GET['page'] ?? 1));
$perPage = 8;

$promotionModel = new Promotion();
$result = $promotionModel->search($filters, $page, $perPage);
$promotions = $result['rows'];
$paginator = new Paginator($result['total'], $perPage, $page);
$summary = $promotionModel->summary($filters);

$userPromotionModel = new UserPromotion();
$participantCounts = [];
foreach ($promotions as $promo) {
    $participantCounts[(int) $promo['id']] = $userPromotionModel->participantsCount((int) $promo['id']);
}

/**
 * Budowanie query stringu z aktualnymi filtrami (do linków sortowania/stronicowania),
 * z możliwością nadpisania wybranych parametrów.
 */
function promotionsQuery(array $filters, array $overrides = []): string
{
    $params = array_merge($filters, $overrides);
    $params = array_filter($params, static fn ($v) => $v !== '' && $v !== null);
    return http_build_query($params);
}

$pageTitle = 'Promocje — panel administratora';
require BASE_PATH . '/views/layout/header.php';
require BASE_PATH . '/views/admin/promotions_list.php';
require BASE_PATH . '/views/layout/footer.php';
