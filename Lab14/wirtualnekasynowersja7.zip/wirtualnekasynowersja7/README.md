# Wirtualne Kasyno — Projekt 10

To mój projekt zaliczeniowy — wirtualne kasyno napisane w czystym PHP (kod obiektowy, bez żadnego frameworka), z bazą danych MySQL, działające na lokalnym serwerze XAMPP. Zarejestrowany użytkownik może zagrać w europejską ruletkę albo w jednorękiego bandytę za wirtualne środki oraz dołączać do promocji w ramach programu lojalnościowego. Administrator z kolei zarządza promocjami i użytkownikami oraz podgląda raporty.

Ważne: środki w grze są w 100% wirtualne. To nie jest hazard za prawdziwe pieniądze — nikt tu nic nie wpłaca ani nie wypłaca.

## Czego potrzebujesz

- XAMPP (Apache + MySQL/MariaDB + PHP 8.1 lub nowszy)
- Przeglądarki internetowej

## Jak to uruchomić

1. Skopiuj cały folder do katalogu `htdocs` swojej instalacji XAMPP — np. `C:\xampp\htdocs\kasyno` na Windowsie albo `/opt/lampp/htdocs/kasyno` na Linuksie.
2. W XAMPP Control Panel odpal moduły **Apache** i **MySQL**.
3. Wejdź na **phpMyAdmin** (`http://localhost/phpmyadmin`), zakładka **Import**, wskaż plik `database/kasyno.sql` z tego projektu i kliknij **Wykonaj/Import**. Powstanie baza `kasyno` z czterema tabelami i kilkoma przykładowymi rekordami — więc zaraz po imporcie nie będzie pusto.
4. Jeśli Twoje MySQL ma inne dane logowania niż domyślne (`root` bez hasła, port `3306`), popraw je w pliku `config.php` w głównym katalogu.
5. Sprawdź, czy katalog `public/uploads/` da się zapisywać. W większości instalacji XAMPP nie trzeba nic dodatkowo ustawiać, ale gdyby wgrywanie obrazków do promocji nie działało, to pierwsze miejsce do sprawdzenia.
6. Otwórz w przeglądarce `http://localhost/wirtualnekasynowersja7/index.php` — powinno od razu przerzucić Cię do logowania.

## Gotowe konta do testowania

Nie trzeba się rejestrować, żeby pokliknać po aplikacji — są dwa gotowe konta:

| Rola          | E-mail            | Hasło    |
|---------------|-------------------|----------|
| Administrator | admin@kasyno.pl   | admin123 |
| Użytkownik    | gracz@kasyno.pl   | gracz123 |

Każde nowo założone konto startuje z saldem 1000 zł (do zmiany w `config.php`, pole `starting_balance`).

## Jak to jest poukładane

```
kasyno/
├── admin/                  # Skrypty panelu administratora (kontrolery)
├── app/
│   ├── Core/                # Klasy bazowe: Database, Auth, Validator, Csrf, Flash, Paginator
│   ├── Models/               # User, Promotion, UserPromotion, Bet
│   ├── Services/             # RouletteService, SlotService, FileUploadService, CsvExporter
│   └── bootstrap.php         # Konfiguracja, autoloader, sesja, obsługa błędów
├── database/kasyno.sql      # Schemat bazy danych + dane startowe
├── public/
│   ├── css/style.css         # Arkusz stylów (motyw kasynowy)
│   └── uploads/               # Przesłane obrazy promocji
├── views/                   # Szablony widoków (czysta prezentacja, bez logiki/SQL)
├── config.php                # Konfiguracja połączenia z bazą danych
├── index.php, login.php, register.php, logout.php,
│   promotions.php, roulette.php, slot.php, account.php   # Skrypty główne (kontrolery)
└── README.md
```

Zasada jest prosta: każdy skrypt w katalogu głównym i w `admin/` to lekki kontroler. Wczytuje `app/bootstrap.php`, korzysta z modeli (`App\Models\...`) do rozmowy z bazą przez PDO i z serwisów (`App\Services\...`) do logiki gier, eksportu czy uploadu, a na końcu dołącza odpowiedni widok z `views/`. Trzymałem się tego, żeby w widokach nie było ani jednego zapytania SQL czy logiki biznesowej — tam tylko wyświetlam dane, które przygotował wcześniej kontroler.

## Co tu właściwie jest zrobione

Całość — 14 klas w `App\Core`, `App\Models` i `App\Services` — napisałem obiektowo, bez przeklejania tej samej logiki w wielu miejscach.

Formularz promocji (`admin/promotion_form.php`) ma cztery różne typy pól (tekst, textarea, liczby, daty, select, checkbox, plik) i pełną walidację po stronie serwera przez własną klasę `App\Core\Validator`. Po nieudanej walidacji wpisane wcześniej wartości nie znikają — dotyczy to każdego formularza w aplikacji (rejestracja, logowanie, ruletka, slot, promocje), poza hasłami i plikiem, co akurat ma sens ze względów bezpieczeństwa.

Lista promocji w panelu admina (`admin/promotions.php`) to pełny CRUD z tabelą HTML, edycją i usuwaniem, do tego wyszukiwarka pełnotekstowa, trzy niezależne filtry (status, zakres dat, zakres bonusu), sortowanie i stronicowanie po stronie serwera, eksport do CSV oraz panel z podsumowaniem. Całość działa we wzorcu Post/Redirect/Get, z jednorazowymi komunikatami flash i własnymi stronami błędów 404/500.

Jeśli chodzi o samą rozgrywkę — jest rejestracja i logowanie z hasłami trzymanymi jako bcrypt (`password_hash`), sesyjna kontrola dostępu przez `App\Core\Auth`, role `user`/`admin`, a także zapamiętywany w bazie motyw (jasny/ciemny) dla każdego użytkownika. W bazie są cztery powiązane tabele, w tym relacja wiele-do-wielu między użytkownikami a promocjami, a obrazek promocji jest fizycznie usuwany z dysku, gdy kasujemy rekord.

## Jeszcze kilka uwag

- Środki w grze są w 100% wirtualne — żadnych prawdziwych płatności.
- Maksymalny rozmiar obrazka do promocji to 2 MB (JPG/PNG/WEBP) — da się to zmienić w `config.php`.
- Brak Composera i frameworka — wystarczy wrzucić folder do `htdocs` i działa od ręki.
