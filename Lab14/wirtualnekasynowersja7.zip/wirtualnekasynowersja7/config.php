<?php
/**
 * config.php
 *
 * Konfiguracja połączenia z bazą danych.
 * Domyślne wartości są zgodne z domyślną instalacją XAMPP
 * (serwer MySQL na localhost, użytkownik root, brak hasła).
 *
 * Jeżeli Twoja konfiguracja XAMPP / MySQL różni się (inny port,
 * hasło do roota, inna nazwa bazy) - zmień wartości poniżej.
 */

return [
    'db' => [
        'driver'   => 'mysql',
        'host'     => '127.0.0.1',
        'port'     => '3306',
        'database' => 'kasyno',
        'username' => 'root',
        'password' => '',
        'charset'  => 'utf8mb4',
    ],

    // Nazwa aplikacji wyświetlana w tytule strony i pasku nawigacji
    'app_name' => 'Wirtualne Kasyno',

    // Saldo startowe przyznawane nowo zarejestrowanemu użytkownikowi
    'starting_balance' => 1000.00,

    // Maksymalny rozmiar przesyłanego pliku (obrazka promocji) w bajtach
    'max_upload_size' => 2 * 1024 * 1024, // 2 MB
];
