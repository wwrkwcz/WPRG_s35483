<?php

declare(strict_types=1);

require __DIR__ . '/app/bootstrap.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Database;
use App\Core\Flash;
use App\Models\Bet;
use App\Models\User;
use App\Services\SlotService;

Auth::requireLogin();

$userId = (int) Auth::id();
$userModel = new User();
$freshUser = $userModel->find($userId);

$errors = [];
$old = ['bet_amount' => '10'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::verify($_POST['csrf_token'] ?? null)) {
        Flash::error('Sesja wygasła, spróbuj ponownie.');
        header('Location: ' . base_url('slot.php'));
        exit;
    }

    $old['bet_amount'] = (string) ($_POST['bet_amount'] ?? '');

    $betAmount = 0.0;
    if ($old['bet_amount'] === '' || !is_numeric($old['bet_amount'])) {
        $errors['bet_amount'] = 'Podaj kwotę zakładu.';
    } else {
        $betAmount = (float) $old['bet_amount'];
        if ($betAmount <= 0) {
            $errors['bet_amount'] = 'Kwota zakładu musi być większa od zera.';
        } elseif ($betAmount > (float) $freshUser['balance']) {
            $errors['bet_amount'] = 'Nie masz wystarczających środków na koncie.';
        }
    }

    if (empty($errors)) {
        $slot = new SlotService();
        $result = $slot->spin($betAmount);

        $newBalance = round((float) $freshUser['balance'] - $betAmount + $result['win_amount'], 2);

        $db = Database::connection();
        $db->beginTransaction();
        try {
            $userModel->updateBalance($userId, $newBalance);
            (new Bet())->create(
                $userId,
                'slot',
                $betAmount,
                'bębny: ' . implode(' ', $result['reels']),
                $result['win'] ? 'win' : 'lose',
                $result['win_amount'],
                $newBalance
            );
            $db->commit();
        } catch (\Throwable $e) {
            $db->rollBack();
            throw $e;
        }

        $_SESSION['slot_last'] = [
            'reels'      => $result['reels'],
            'bet_amount' => $betAmount,
            'win'        => $result['win'],
            'win_amount' => $result['win_amount'],
        ];

        if ($result['win']) {
            Flash::success('Wygrałeś ' . money($result['win_amount']) . '! Bębny: ' . implode(' ', $result['reels']));
        } else {
            Flash::error('Przegrałeś. Bębny: ' . implode(' ', $result['reels']));
        }

        header('Location: ' . base_url('slot.php'));
        exit;
    }
}

$lastResult = $_SESSION['slot_last'] ?? null;
unset($_SESSION['slot_last']);
$deferFlash = $lastResult !== null;

$user = $userModel->find($userId);

$pageTitle = 'Jednoręki bandyta';
require BASE_PATH . '/views/layout/header.php';
require BASE_PATH . '/views/games/slot.php';
require BASE_PATH . '/views/layout/footer.php';
