<?php

declare(strict_types=1);

require __DIR__ . '/app/bootstrap.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Database;
use App\Core\Flash;
use App\Models\Bet;
use App\Models\User;
use App\Services\RouletteService;

Auth::requireLogin();

$userId = (int) Auth::id();
$userModel = new User();
$freshUser = $userModel->find($userId);

$errors = [];
$old = ['bet_type' => 'color', 'bet_number' => '', 'bet_color' => 'red', 'bet_parity' => 'even', 'bet_amount' => '10'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::verify($_POST['csrf_token'] ?? null)) {
        Flash::error('Sesja wygasła, spróbuj ponownie.');
        header('Location: ' . base_url('roulette.php'));
        exit;
    }

    $old['bet_type'] = (string) ($_POST['bet_type'] ?? 'color');
    $old['bet_number'] = (string) ($_POST['bet_number'] ?? '');
    $old['bet_color'] = (string) ($_POST['bet_color'] ?? 'red');
    $old['bet_parity'] = (string) ($_POST['bet_parity'] ?? 'even');
    $old['bet_amount'] = (string) ($_POST['bet_amount'] ?? '');

    if (!in_array($old['bet_type'], ['number', 'color', 'parity'], true)) {
        $errors['bet_type'] = 'Wybierz rodzaj zakładu.';
    }

    $betValue = '';
    if ($old['bet_type'] === 'number') {
        if ($old['bet_number'] === '' || !is_numeric($old['bet_number']) || (int) $old['bet_number'] < 0 || (int) $old['bet_number'] > 36) {
            $errors['bet_number'] = 'Podaj liczbę od 0 do 36.';
        } else {
            $betValue = (string) (int) $old['bet_number'];
        }
    } elseif ($old['bet_type'] === 'color') {
        if (!in_array($old['bet_color'], ['red', 'black'], true)) {
            $errors['bet_color'] = 'Wybierz kolor.';
        } else {
            $betValue = $old['bet_color'];
        }
    } elseif ($old['bet_type'] === 'parity') {
        if (!in_array($old['bet_parity'], ['even', 'odd'], true)) {
            $errors['bet_parity'] = 'Wybierz parzystość.';
        } else {
            $betValue = $old['bet_parity'];
        }
    }

    $betAmount = 0.0;
    if ($old['bet_amount'] === '' || !is_numeric($old['bet_amount'])) {
        $errors['bet_amount'] = 'Podaj kwotę zakładu.';
    } else {
        $betAmount = (float) $old['bet_amount'];
        if ($betAmount <= 0) {
            $errors['bet_amount'] = 'Kwota zakładu musi być większa od zera.';
        } elseif ($betAmount > (float) $freshUser['balance']) {
            $errors['bet_amount'] = 'Nie masz wystarczających środków na koncie.';
        }
    }

    if (empty($errors)) {
        $roulette = new RouletteService();
        $drawn = $roulette->spin();
        $resolved = $roulette->resolve($old['bet_type'], $betValue, $betAmount, $drawn);

        $newBalance = round((float) $freshUser['balance'] - $betAmount + $resolved['win_amount'], 2);

        $betLabel = match ($old['bet_type']) {
            'number' => 'liczba ' . $betValue,
            'color'  => 'kolor ' . ($betValue === 'red' ? 'czerwony' : 'czarny'),
            'parity' => $betValue === 'even' ? 'parzyste' : 'nieparzyste',
        };

        $db = Database::connection();
        $db->beginTransaction();
        try {
            $userModel->updateBalance($userId, $newBalance);
            (new Bet())->create(
                $userId,
                'roulette',
                $betAmount,
                $betLabel . ' | wylosowano: ' . $resolved['drawn_number'],
                $resolved['win'] ? 'win' : 'lose',
                $resolved['win_amount'],
                $newBalance
            );
            $db->commit();
        } catch (\Throwable $e) {
            $db->rollBack();
            throw $e;
        }

        $_SESSION['roulette_last'] = [
            'bet_label'    => $betLabel,
            'bet_amount'   => $betAmount,
            'drawn_number' => $resolved['drawn_number'],
            'drawn_color'  => $resolved['drawn_color'],
            'win'          => $resolved['win'],
            'win_amount'   => $resolved['win_amount'],
        ];

        if ($resolved['win']) {
            Flash::success('Wygrałeś! Wylosowano ' . $resolved['drawn_number'] . '. Wygrana: ' . money($resolved['win_amount']) . '.');
        } else {
            Flash::error('Przegrałeś. Wylosowano ' . $resolved['drawn_number'] . '.');
        }

        header('Location: ' . base_url('roulette.php'));
        exit;
    }
}

$lastResult = $_SESSION['roulette_last'] ?? null;
unset($_SESSION['roulette_last']);
$deferFlash = $lastResult !== null;

$user = $userModel->find($userId);

$pageTitle = 'Ruletka';
require BASE_PATH . '/views/layout/header.php';
require BASE_PATH . '/views/games/roulette.php';
require BASE_PATH . '/views/layout/footer.php';
