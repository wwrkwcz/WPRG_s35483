-- Skrypt tworzący bazę danych dla projektu Wirtualne Kasyno.
-- Testowany na MySQL 8.0 (XAMPP). Przed importem upewnij się,
-- że w phpMyAdmin nie masz jeszcze bazy o nazwie "kasyno",
-- albo usuń ją ręcznie, żeby uniknąć konfliktów.

CREATE DATABASE IF NOT EXISTS kasyno CHARACTER SET utf8mb4 COLLATE utf8mb4_polish_ci;
USE kasyno;

-- Tabela użytkowników. Pole "role" decyduje o tym, czy ktoś ma dostęp
-- do panelu administratora. Saldo startowe ustawiam na 1000 zł,
-- żeby można było od razu testować gry bez ręcznego doładowywania.
CREATE TABLE IF NOT EXISTS users (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    surname         VARCHAR(100) NOT NULL,
    email           VARCHAR(150) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    role            ENUM('user','admin') NOT NULL DEFAULT 'user',
    balance         DECIMAL(10,2) NOT NULL DEFAULT 1000.00,
    theme           ENUM('light','dark') NOT NULL DEFAULT 'dark',
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Promocje to główny zasób zarządzany przez administratora (pełny CRUD).
-- Kolumna "featured" służy do wyróżniania wybranych ofert na górze listy.
-- Obrazek jest opcjonalny — jeśli nie zostanie wgrany, widok go po prostu pomija.
CREATE TABLE IF NOT EXISTS promotions (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title           VARCHAR(150) NOT NULL,
    description     TEXT NOT NULL,
    bonus_percent   TINYINT UNSIGNED NOT NULL,
    min_deposit     DECIMAL(10,2) NOT NULL DEFAULT 0,
    valid_from      DATE NOT NULL,
    valid_to        DATE NOT NULL,
    status          ENUM('active','inactive') NOT NULL DEFAULT 'active',
    featured        TINYINT(1) NOT NULL DEFAULT 0,
    image_path      VARCHAR(255) NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabela łącząca użytkowników z promocjami (relacja wiele do wielu).
-- Klucz unikalny na parze (user_id, promotion_id) blokuje możliwość
-- dwukrotnego dołączenia do tej samej promocji przez tego samego gracza.
CREATE TABLE IF NOT EXISTS user_promotions (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         INT UNSIGNED NOT NULL,
    promotion_id    INT UNSIGNED NOT NULL,
    joined_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_user_promo (user_id, promotion_id),
    CONSTRAINT fk_up_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_up_promo FOREIGN KEY (promotion_id) REFERENCES promotions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Historia wszystkich zakładów — zarówno ruletki, jak i jednoręki bandyty.
-- Zapisuję tu saldo po każdej grze, żeby można było odtworzyć historię konta
-- bez przeliczania wszystkich zakładów od nowa.
CREATE TABLE IF NOT EXISTS bets (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         INT UNSIGNED NOT NULL,
    game_type       ENUM('roulette','slot') NOT NULL,
    bet_amount      DECIMAL(10,2) NOT NULL,
    bet_details     VARCHAR(255) NOT NULL,
    result          ENUM('win','lose') NOT NULL,
    win_amount      DECIMAL(10,2) NOT NULL DEFAULT 0,
    balance_after   DECIMAL(10,2) NOT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_bets_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Dane testowe — dwa konta do testowania aplikacji.
-- Hasła są zahashowane bcryptem, więc nie da się ich odczytać z bazy.
-- admin@kasyno.pl / admin123
INSERT INTO users (name, surname, email, password_hash, role, balance, theme) VALUES
('Admin', 'Admin', 'admin@kasyno.pl', '$2y$10$XmEDhwvI.8EmuyIprcQy2eoLqhHOUX8DlSSOUZi5/JQgYN5GQWtIa', 'admin', 10000.00, 'dark');
-- gracz@kasyno.pl / gracz123
INSERT INTO users (name, surname, email, password_hash, role, balance, theme) VALUES
('Gracz', 'Gracz', 'gracz@kasyno.pl', '$2y$10$rRbAM0VP9Q1bqkA7waQuB.CSLsH6ExMJVsPPSEK2ghpYSaZIfvvKW', 'user', 1000.00, 'dark');

-- Kilka przykładowych promocji żeby lista nie była pusta od razu po imporcie.
INSERT INTO promotions (title, description, bonus_percent, min_deposit, valid_from, valid_to, status, featured) VALUES
('Bonus powitalny', 'Doładuj konto po raz pierwszy i odbierz dodatkowe środki na start. Promocja dla nowych użytkowników kasyna.', 100, 50.00, '2026-01-01', '2026-12-31', 'active', 1),
('Weekendowy zwrot', 'Co weekend zwracamy część przegranych środków jako bonus do wykorzystania w ruletce i jednorękim bandycie.', 15, 20.00, '2026-06-01', '2026-09-30', 'active', 0),
('Letnia promocja VIP', 'Specjalna oferta dla najbardziej aktywnych graczy w okresie letnim.', 25, 200.00, '2026-06-01', '2026-08-31', 'active', 1),
('Zimowy bonus (zakończony)', 'Archiwalna promocja świąteczna z poprzedniego sezonu.', 30, 100.00, '2025-12-01', '2025-12-31', 'inactive', 0);
