<?php
/**
 * Plik startowy aplikacji — dołączany na początku każdego skryptu
 * (index.php, login.php, roulette.php, admin/promotions.php itd.).
 *
 * Zajmuje się kilkoma rzeczami naraz: wczytuje konfigurację,
 * rejestruje autoloader klas, uruchamia sesję oraz ustawia
 * obsługę błędów tak, żeby użytkownik nigdy nie zobaczył
 * surowego stacktrace'a PHP — zamiast tego dostaje ładną stronę błędu.
 * Na końcu definiuje pare pomocniczych funkcji używanych w widokach.
 */

declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '0');

define('BASE_PATH', dirname(__DIR__));

// Konfiguracja aplikacji (dane do bazy, nazwa aplikacji itp.)
$GLOBALS['config'] = require BASE_PATH . '/config.php';

// Autoloader — zamienia App\Core\Auth na /app/Core/Auth.php i go dołącza.
// Dzięki temu nie muszę pisać ręcznie require na górze każdego pliku.
spl_autoload_register(function (string $class): void {
    if (strpos($class, 'App\\') !== 0) {
        return;
    }
    $relative = substr($class, strlen('App\\'));
    $path = BASE_PATH . '/app/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($path)) {
        require $path;
    }
});

use App\Core\Flash;

// Sesja musi startować raz — sprawdzam status, żeby nie dostać ostrzeżenia
// o wielokrotnym wywołaniu session_start().
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Globalny handler wyjątków — loguje błąd do error_log i pokazuje stronę 500,
// zamiast wywalać szczegóły stacktrace'a na produkcji.
set_exception_handler(function (Throwable $e): void {
    error_log('[KASYNO] Nieobsłużony wyjątek: ' . $e->getMessage() . ' w ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    require BASE_PATH . '/views/errors/500.php';
    exit;
});

// To samo dla zwykłych błędów PHP (E_WARNING, E_NOTICE itd.).
// Poważne błędy (E_ERROR, E_PARSE) przerywają działanie i pokazują stronę 500,
// pozostałe są tylko logowane.
set_error_handler(function (int $severity, string $message, string $file, int $line): bool {
    error_log("[KASYNO] PHP error ($severity): $message w $file:$line");
    if ($severity & (E_ERROR | E_PARSE | E_CORE_ERROR | E_COMPILE_ERROR)) {
        http_response_code(500);
        require BASE_PATH . '/views/errors/500.php';
        exit;
    }
    return true;
});

// Wyświetla stronę 404 i zatrzymuje wykonywanie skryptu.
function abort404(): void
{
    http_response_code(404);
    require BASE_PATH . '/views/errors/404.php';
    exit;
}

// Escapuje ciąg do bezpiecznego wypisania w HTML (zapobiega XSS).
function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

// Formatuje kwotę w złotówkach z dwoma miejscami po przecinku.
function money(float $value): string
{
    return number_format($value, 2, ',', ' ') . ' zł';
}

// Buduje URL do zasobu statycznego (CSS, JS, obrazki).
function asset(string $path): string
{
    return base_url($path);
}

// Zwraca bazowy URL aplikacji. Funkcja zapamiętuje wynik przy pierwszym wywołaniu,
// więc nie liczy go za każdym razem od nowa. Obsługuje też sytuację, gdy skrypt
// leży w podkatalogu admin/ — w takim przypadku cofa się o jeden poziom wyżej.
function base_url(string $path = ''): string
{
    static $base = null;
    if ($base === null) {
        $script = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
        if (basename($script) === 'admin') {
            $script = dirname($script);
        }
        $base = rtrim($script, '/');
    }
    return $base . '/' . ltrim($path, '/');
}
