<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use PDO;

/**
 * Model promocji — to główny zasób w projekcie, który demonstruje pełny CRUD.
 *
 * Metoda search() obsługuje jednocześnie wyszukiwanie pełnotekstowe,
 * filtrowanie po kilku kryteriach (status, daty, zakres bonusu),
 * sortowanie i stronicowanie — wszystko po stronie bazy danych w jednym zapytaniu.
 * buildWhere() składa dynamicznie klauzulę WHERE na podstawie aktywnych filtrów.
 */
class Promotion
{
    private PDO $db;

    // Biała lista kolumn dopuszczonych w ORDER BY — zapobiega SQL injection,
    // bo nie można parametryzować nazw kolumn w PDO.
    private const SORTABLE = ['title', 'bonus_percent', 'valid_from', 'valid_to', 'created_at'];

    public function __construct()
    {
        $this->db = Database::connection();
    }

    public function find(int $id): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM promotions WHERE id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    // Zwraca tylko aktywne promocje, których czas trwania obejmuje dzisiaj.
    // Wyróżnione (featured = 1) trafiają na górę listy.
    public function allActive(): array
    {
        return $this->db->query(
            "SELECT * FROM promotions WHERE status = 'active' AND CURDATE() BETWEEN valid_from AND valid_to ORDER BY featured DESC, valid_to ASC"
        )->fetchAll();
    }

    /**
     * Wyszukiwanie z filtrami, sortowaniem i stronicowaniem dla panelu admina.
     *
     * @param array{q?:string,status?:string,date_from?:string,date_to?:string,bonus_min?:string,bonus_max?:string,sort?:string,dir?:string} $filters
     */
    public function search(array $filters, int $page, int $perPage): array
    {
        [$where, $params] = $this->buildWhere($filters);

        // Walidacja kolumny sortowania przez białą listę zamiast parametru PDO.
        $sort = in_array($filters['sort'] ?? '', self::SORTABLE, true) ? $filters['sort'] : 'created_at';
        $dir  = (($filters['dir'] ?? 'desc') === 'asc') ? 'ASC' : 'DESC';

        // Najpierw liczę łączną liczbę wyników (do paginatora), potem pobieram stronę.
        $countStmt = $this->db->prepare("SELECT COUNT(*) FROM promotions $where");
        $countStmt->execute($params);
        $total = (int) $countStmt->fetchColumn();

        $offset = ($page - 1) * $perPage;
        $sql = "SELECT * FROM promotions $where ORDER BY $sort $dir LIMIT :limit OFFSET :offset";
        $stmt = $this->db->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

        return ['rows' => $stmt->fetchAll(), 'total' => $total];
    }

    // Wersja search() bez LIMIT/OFFSET — do eksportu całej przefiltrowanej listy do CSV.
    public function searchAll(array $filters): array
    {
        [$where, $params] = $this->buildWhere($filters);
        $sort = in_array($filters['sort'] ?? '', self::SORTABLE, true) ? $filters['sort'] : 'created_at';
        $dir  = (($filters['dir'] ?? 'desc') === 'asc') ? 'ASC' : 'DESC';
        $stmt = $this->db->prepare("SELECT * FROM promotions $where ORDER BY $sort $dir");
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    // Podsumowanie (liczba rekordów, ile aktywnych, średni bonus) zgodne
    // z aktywnymi filtrami — wyświetlane nad tabelą w panelu admina.
    public function summary(array $filters): array
    {
        [$where, $params] = $this->buildWhere($filters);
        $sql = "SELECT COUNT(*) AS total,
                       SUM(status = 'active') AS active_count,
                       COALESCE(AVG(bonus_percent), 0) AS avg_bonus,
                       COALESCE(SUM(min_deposit), 0) AS sum_min_deposit
                FROM promotions $where";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch();
        return [
            'total'           => (int) $row['total'],
            'active_count'    => (int) $row['active_count'],
            'avg_bonus'       => round((float) $row['avg_bonus'], 1),
            'sum_min_deposit' => (float) $row['sum_min_deposit'],
        ];
    }

    // Buduje dynamiczną klauzulę WHERE na podstawie przekazanych filtrów.
    // Zwraca parę [string $where, array $params] gotową do użycia w prepare/execute.
    private function buildWhere(array $filters): array
    {
        $conditions = [];
        $params = [];

        if (!empty($filters['q'])) {
            $conditions[] = '(title LIKE :q OR description LIKE :q)';
            $params[':q'] = '%' . $filters['q'] . '%';
        }
        if (!empty($filters['status']) && in_array($filters['status'], ['active', 'inactive'], true)) {
            $conditions[] = 'status = :status';
            $params[':status'] = $filters['status'];
        }
        if (!empty($filters['date_from'])) {
            $conditions[] = 'valid_from >= :date_from';
            $params[':date_from'] = $filters['date_from'];
        }
        if (!empty($filters['date_to'])) {
            $conditions[] = 'valid_to <= :date_to';
            $params[':date_to'] = $filters['date_to'];
        }
        if (isset($filters['bonus_min']) && $filters['bonus_min'] !== '') {
            $conditions[] = 'bonus_percent >= :bonus_min';
            $params[':bonus_min'] = (int) $filters['bonus_min'];
        }
        if (isset($filters['bonus_max']) && $filters['bonus_max'] !== '') {
            $conditions[] = 'bonus_percent <= :bonus_max';
            $params[':bonus_max'] = (int) $filters['bonus_max'];
        }

        $where = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';
        return [$where, $params];
    }

    public function create(array $data): int
    {
        $stmt = $this->db->prepare(
            'INSERT INTO promotions (title, description, bonus_percent, min_deposit, valid_from, valid_to, status, featured, image_path)
             VALUES (:title, :description, :bonus_percent, :min_deposit, :valid_from, :valid_to, :status, :featured, :image_path)'
        );
        $stmt->execute([
            ':title'         => $data['title'],
            ':description'   => $data['description'],
            ':bonus_percent' => $data['bonus_percent'],
            ':min_deposit'   => $data['min_deposit'],
            ':valid_from'    => $data['valid_from'],
            ':valid_to'      => $data['valid_to'],
            ':status'        => $data['status'],
            ':featured'      => $data['featured'] ? 1 : 0,
            ':image_path'    => $data['image_path'],
        ]);
        return (int) $this->db->lastInsertId();
    }

    public function update(int $id, array $data): void
    {
        $stmt = $this->db->prepare(
            'UPDATE promotions SET title = :title, description = :description, bonus_percent = :bonus_percent,
             min_deposit = :min_deposit, valid_from = :valid_from, valid_to = :valid_to, status = :status,
             featured = :featured, image_path = :image_path WHERE id = :id'
        );
        $stmt->execute([
            ':title'         => $data['title'],
            ':description'   => $data['description'],
            ':bonus_percent' => $data['bonus_percent'],
            ':min_deposit'   => $data['min_deposit'],
            ':valid_from'    => $data['valid_from'],
            ':valid_to'      => $data['valid_to'],
            ':status'        => $data['status'],
            ':featured'      => $data['featured'] ? 1 : 0,
            ':image_path'    => $data['image_path'],
            ':id'            => $id,
        ]);
    }

    public function delete(int $id): void
    {
        $stmt = $this->db->prepare('DELETE FROM promotions WHERE id = ?');
        $stmt->execute([$id]);
    }
}
