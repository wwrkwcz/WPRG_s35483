<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use PDO;

/**
 * Obsługuje relację wiele-do-wielu między użytkownikami a promocjami.
 * Jeden użytkownik może przystąpić do wielu promocji, a jedna promocja
 * może mieć wielu uczestników — ta tabela łącząca to rejestruje.
 */
class UserPromotion
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::connection();
    }

    public function hasJoined(int $userId, int $promotionId): bool
    {
        $stmt = $this->db->prepare('SELECT 1 FROM user_promotions WHERE user_id = ? AND promotion_id = ?');
        $stmt->execute([$userId, $promotionId]);
        return $stmt->fetchColumn() !== false;
    }

    // Dołącza użytkownika do promocji. Sprawdzam wcześniej hasJoined(),
    // żeby nie dublować wpisów — baza też ma klucz unikalny, ale wolę
    // nie polegać na złapaniu wyjątku jako logiki biznesowej.
    public function join(int $userId, int $promotionId): void
    {
        if ($this->hasJoined($userId, $promotionId)) {
            return;
        }
        $stmt = $this->db->prepare('INSERT INTO user_promotions (user_id, promotion_id) VALUES (?, ?)');
        $stmt->execute([$userId, $promotionId]);
    }

    // Zwraca tablicę ID promocji, do których dany użytkownik już dołączył.
    // Używam tego w widoku listy promocji, żeby ukryć lub wyszarzyć przycisk "Dołącz".
    public function joinedPromotionIds(int $userId): array
    {
        $stmt = $this->db->prepare('SELECT promotion_id FROM user_promotions WHERE user_id = ?');
        $stmt->execute([$userId]);
        return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
    }

    public function participantsCount(int $promotionId): int
    {
        $stmt = $this->db->prepare('SELECT COUNT(*) FROM user_promotions WHERE promotion_id = ?');
        $stmt->execute([$promotionId]);
        return (int) $stmt->fetchColumn();
    }
}
