<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use PDO;

/**
 * Model użytkownika — obsługuje rejestrację, logowanie i zarządzanie kontem.
 * Hasła są zawsze hashowane przez password_hash() przed zapisem do bazy,
 * nigdy nie trzymam ich w formie jawnej.
 */
class User
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::connection();
    }

    public function find(int $id): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM users WHERE id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    public function findByEmail(string $email): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    public function emailExists(string $email): bool
    {
        return $this->findByEmail($email) !== null;
    }

    public function create(string $name, string $surname, string $email, string $password, float $startingBalance): int
    {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $this->db->prepare(
            'INSERT INTO users (name, surname, email, password_hash, role, balance, theme) VALUES (?, ?, ?, ?, "user", ?, "dark")'
        );
        $stmt->execute([$name, $surname, $email, $hash, $startingBalance]);
        return (int) $this->db->lastInsertId();
    }

    public function verifyPassword(array $user, string $password): bool
    {
        return password_verify($password, $user['password_hash']);
    }

    public function updateBalance(int $userId, float $newBalance): void
    {
        $stmt = $this->db->prepare('UPDATE users SET balance = ? WHERE id = ?');
        $stmt->execute([$newBalance, $userId]);
    }

    public function updateTheme(int $userId, string $theme): void
    {
        $stmt = $this->db->prepare('UPDATE users SET theme = ? WHERE id = ?');
        $stmt->execute([$theme, $userId]);
    }

    // Zwraca listę wszystkich użytkowników wzbogaconą o podstawowe statystyki
    // (liczba zakładów, suma obstawionych środków, data ostatniej aktywności).
    // Używam LEFT JOIN, bo chcę też wyświetlić użytkowników, którzy jeszcze
    // nie zagrali żadnej gry.
    public function allWithActivity(): array
    {
        $sql = "SELECT u.id, u.name, u.surname, u.email, u.role, u.balance, u.created_at,
                       COUNT(b.id) AS bets_count,
                       COALESCE(SUM(b.bet_amount), 0) AS total_wagered,
                       MAX(b.created_at) AS last_activity
                FROM users u
                LEFT JOIN bets b ON b.user_id = u.id
                GROUP BY u.id
                ORDER BY u.created_at DESC";
        return $this->db->query($sql)->fetchAll();
    }

    public function count(): int
    {
        return (int) $this->db->query('SELECT COUNT(*) FROM users')->fetchColumn();
    }
}
