<?php

declare(strict_types=1);

namespace App\Services;

/**
 * Obsługuje przesyłanie obrazków do promocji — waliduje plik
 * i zapisuje go w katalogu public/uploads z losową nazwą.
 *
 * Typ pliku sprawdzam przez finfo (magic bytes), a nie przez rozszerzenie,
 * bo rozszerzenie można łatwo sfałszować. Dozwolone formaty to JPG, PNG i WEBP.
 * Plik jest opcjonalny — jeśli gracz nie wgrywa obrazka, metoda handle()
 * zwraca [true, null] i wszystko działa dalej normalnie.
 */
class FileUploadService
{
    private const ALLOWED_MIME = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];

    private string $uploadDir;
    private int $maxSize;

    public function __construct(string $uploadDir, int $maxSize)
    {
        $this->uploadDir = rtrim($uploadDir, '/');
        $this->maxSize = $maxSize;
    }

    /**
     * Przetwarza przesłany plik i zwraca parę [bool $ok, string|null $pathOrError].
     * Ścieżka jest relatywna (zapisywana w bazie), np. "public/uploads/promo_abc123.jpg".
     */
    public function handle(array $file): array
    {
        // Brak pliku to nie błąd — obrazek jest polem opcjonalnym.
        if (!isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
            return [true, null];
        }
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return [false, 'Wystąpił błąd podczas przesyłania pliku.'];
        }
        if ($file['size'] > $this->maxSize) {
            return [false, 'Plik jest za duży (maksymalnie ' . round($this->maxSize / 1024 / 1024, 1) . ' MB).'];
        }

        // Sprawdzam typ pliku przez magic bytes, nie przez rozszerzenie.
        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($file['tmp_name']);
        if (!isset(self::ALLOWED_MIME[$mime])) {
            return [false, 'Niedozwolony typ pliku. Dozwolone formaty: JPG, PNG, WEBP.'];
        }

        $extension = self::ALLOWED_MIME[$mime];
        // Losowa nazwa pliku zapobiega kolizjom i ukrywa oryginalne nazwy.
        $filename = 'promo_' . bin2hex(random_bytes(8)) . '.' . $extension;

        if (!is_dir($this->uploadDir)) {
            mkdir($this->uploadDir, 0755, true);
        }

        if (!move_uploaded_file($file['tmp_name'], $this->uploadDir . '/' . $filename)) {
            return [false, 'Nie udało się zapisać przesłanego pliku na serwerze.'];
        }

        return [true, 'public/uploads/' . $filename];
    }

    // Usuwa plik z dysku przy kasowaniu rekordu promocji.
    // basename() zabezpiecza przed path traversal w przypadku złośliwej ścieżki w bazie.
    public function delete(?string $relativePath): void
    {
        if ($relativePath === null || $relativePath === '') {
            return;
        }
        $fullPath = $this->uploadDir . '/' . basename($relativePath);
        if (is_file($fullPath)) {
            @unlink($fullPath);
        }
    }
}
