<?php

declare(strict_types=1);

namespace App\Services;

/**
 * Wysyła tablicę danych jako plik CSV do pobrania przez przeglądarkę.
 *
 * Używam php://output jako strumienia wyjściowego, żeby nie trzymać
 * całego pliku w pamięci — przy dużych exportach to ma znaczenie.
 * BOM na początku pliku jest potrzebny do poprawnego wyświetlania
 * polskich znaków po otwarciu w Excelu (bez niego ą, ę, ó itd. się sypią).
 */
class CsvExporter
{
    /**
     * @param array<int,array<string,mixed>> $rows
     * @param array<string,string> $columns  mapowanie pole_bazy => nagłówek_kolumny
     */
    public static function stream(array $rows, array $columns, string $filename): void
    {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        $output = fopen('php://output', 'w');
        fwrite($output, "\xEF\xBB\xBF"); // BOM dla Excela
        fputcsv($output, array_values($columns), ';');

        foreach ($rows as $row) {
            $line = [];
            foreach (array_keys($columns) as $field) {
                $line[] = $row[$field] ?? '';
            }
            fputcsv($output, $line, ';');
        }

        fclose($output);
        exit;
    }
}
