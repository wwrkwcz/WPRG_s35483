<?php

declare(strict_types=1);

namespace App\Services;

/**
 * Logika jednoręki bandyta — trzy bębny, każdy losuje symbol
 * z ważonym rozkładem prawdopodobieństwa.
 *
 * Symbole mają różne wagi: im rzadszy (niższa waga), tym wyższy mnożnik wygranej.
 * Siódemka (7️⃣) wypłaca 100x stawki, ale trafia wyjątkowo rzadko.
 * Para (2 takie same) daje zwrot stawki, żeby gra nie była zbyt brutalna.
 */
class SlotService
{
    // Waga decyduje o tym, jak często dany symbol trafia na bęben.
    // Im wyższa waga, tym częstszy symbol.
    private const SYMBOLS = [
        '🍒' => 40,
        '🍋' => 30,
        '🔔' => 18,
        '⭐' => 8,
        '💎' => 3,
        '7️⃣' => 1,
    ];

    // Mnożnik wygranej za trafienie trzech takich samych symboli.
    private const TRIPLE_MULTIPLIER = [
        '🍒' => 3,
        '🍋' => 5,
        '🔔' => 10,
        '⭐' => 20,
        '💎' => 50,
        '7️⃣' => 100,
    ];

    // Para (dwa takie same) zwraca dokładnie stawkę — gracz wychodzi na zero.
    private const PAIR_MULTIPLIER = 1.0;

    // Losuje jeden symbol z uwzględnieniem wag (ważona loteria).
    public function spinReel(): string
    {
        $total = array_sum(self::SYMBOLS);
        $roll = random_int(1, $total);
        $cumulative = 0;
        foreach (self::SYMBOLS as $symbol => $weight) {
            $cumulative += $weight;
            if ($roll <= $cumulative) {
                return $symbol;
            }
        }
        return '🍒'; // fallback, w praktyce nigdy nie powinno tu trafić
    }

    /**
     * @return array{reels: string[], win: bool, win_amount: float}
     */
    public function spin(float $betAmount): array
    {
        $reels = [$this->spinReel(), $this->spinReel(), $this->spinReel()];
        $counts = array_count_values($reels);
        $maxCount = max($counts);
        $winAmount = 0.0;

        if ($maxCount === 3) {
            $symbol = array_keys($counts, 3)[0];
            $winAmount = round($betAmount * self::TRIPLE_MULTIPLIER[$symbol], 2);
        } elseif ($maxCount === 2) {
            $winAmount = round($betAmount * self::PAIR_MULTIPLIER, 2);
        }

        return [
            'reels'      => $reels,
            'win'        => $winAmount > 0,
            'win_amount' => $winAmount,
        ];
    }
}
