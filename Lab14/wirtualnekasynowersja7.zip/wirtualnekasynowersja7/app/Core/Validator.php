<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Walidator danych z formularzy — napisany od zera na potrzeby projektu.
 *
 * Każda metoda sprawdza jedno pole i w razie błędu dodaje komunikat
 * do tablicy $errors. Można łączyć wywołania w łańcuch (fluent interface),
 * bo każda metoda zwraca $this. Na końcu wywołuję fails(), żeby sprawdzić
 * czy cokolwiek nie przeszło walidacji.
 *
 * Celowo nie używam żadnej gotowej biblioteki — to projekt zaliczeniowy
 * i chciałem pokazać, jak taki mechanizm działa od środka.
 */
class Validator
{
    /** @var array<string,string> */
    private array $errors = [];

    /** @var array<string,mixed> */
    private array $data;

    public function __construct(array $data)
    {
        $this->data = $data;
    }

    public function get(string $field): mixed
    {
        return $this->data[$field] ?? null;
    }

    // Pole jest wymagane — sprawdzam po trim(), żeby sama spacja nie przechodziła.
    public function required(string $field, string $label): self
    {
        $value = trim((string) ($this->data[$field] ?? ''));
        if ($value === '') {
            $this->addError($field, "Pole „{$label}” jest wymagane.");
        }
        return $this;
    }

    public function maxLength(string $field, int $max, string $label): self
    {
        $value = (string) ($this->data[$field] ?? '');
        if (mb_strlen($value) > $max) {
            $this->addError($field, "Pole „{$label}” może mieć maksymalnie $max znaków.");
        }
        return $this;
    }

    public function minLength(string $field, int $min, string $label): self
    {
        $value = trim((string) ($this->data[$field] ?? ''));
        if ($value !== '' && mb_strlen($value) < $min) {
            $this->addError($field, "Pole „{$label}” musi mieć co najmniej $min znaków.");
        }
        return $this;
    }

    public function email(string $field, string $label): self
    {
        $value = trim((string) ($this->data[$field] ?? ''));
        if ($value !== '' && filter_var($value, FILTER_VALIDATE_EMAIL) === false) {
            $this->addError($field, "Pole „{$label}” musi zawierać poprawny adres e-mail.");
        }
        return $this;
    }

    public function numeric(string $field, string $label): self
    {
        $value = $this->data[$field] ?? '';
        if ($value !== '' && !is_numeric($value)) {
            $this->addError($field, "Pole „{$label}” musi być liczbą.");
        }
        return $this;
    }

    public function range(string $field, float $min, float $max, string $label): self
    {
        $value = $this->data[$field] ?? '';
        if ($value !== '' && is_numeric($value) && ((float) $value < $min || (float) $value > $max)) {
            $this->addError($field, "Pole „{$label}” musi mieć wartość od $min do $max.");
        }
        return $this;
    }

    public function date(string $field, string $label): self
    {
        $value = trim((string) ($this->data[$field] ?? ''));
        if ($value !== '') {
            $d = \DateTime::createFromFormat('Y-m-d', $value);
            if (!$d || $d->format('Y-m-d') !== $value) {
                $this->addError($field, "Pole „{$label}” musi być poprawną datą (RRRR-MM-DD).");
            }
        }
        return $this;
    }

    // Sprawdza, że data w $field nie jest wcześniejsza niż w $otherField.
    // Używam tego przy walidacji par dat "od / do" w formularzu promocji.
    public function dateAfterOrEqual(string $field, string $otherField, string $label): self
    {
        $a = $this->data[$field] ?? '';
        $b = $this->data[$otherField] ?? '';
        if ($a !== '' && $b !== '' && strtotime((string) $a) !== false && strtotime((string) $b) !== false) {
            if (strtotime((string) $a) < strtotime((string) $b)) {
                $this->addError($field, "Pole „{$label}” nie może być wcześniejsze niż data początkowa.");
            }
        }
        return $this;
    }

    // Sprawdza czy wartość należy do dopuszczonego zestawu (np. 'active'/'inactive').
    public function in(string $field, array $allowed, string $label): self
    {
        $value = $this->data[$field] ?? null;
        if ($value !== null && $value !== '' && !in_array($value, $allowed, true)) {
            $this->addError($field, "Pole „{$label}” ma niedozwoloną wartość.");
        }
        return $this;
    }

    // Porównuje dwa pola — używam do weryfikacji powtórzonego hasła.
    public function matches(string $field, string $otherField, string $label): self
    {
        if (($this->data[$field] ?? null) !== ($this->data[$otherField] ?? null)) {
            $this->addError($field, "Pole „{$label}” nie jest zgodne.");
        }
        return $this;
    }

    // Dodaje błąd tylko dla pierwszego naruszenia na danym polu —
    // żeby nie wyświetlać kilku komunikatów naraz.
    private function addError(string $field, string $message): void
    {
        if (!isset($this->errors[$field])) {
            $this->errors[$field] = $message;
        }
    }

    public function fails(): bool
    {
        return count($this->errors) > 0;
    }

    public function errors(): array
    {
        return $this->errors;
    }

    public function error(string $field): ?string
    {
        return $this->errors[$field] ?? null;
    }
}
