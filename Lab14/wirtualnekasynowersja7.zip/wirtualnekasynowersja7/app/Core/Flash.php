<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Jednorazowe komunikaty dla użytkownika przekazywane przez sesję.
 *
 * Wzorzec działa tak: po przetworzeniu formularza POST ustawiam komunikat
 * (np. "Promocja zapisana"), robię redirect na GET, a tam komunikat jest
 * odczytywany i od razu usuwany z sesji — stąd nazwa "flash".
 * Dzięki temu odświeżenie strony nie pokazuje komunikatu drugi raz
 * i nie zapisuje formularza ponownie.
 */
class Flash
{
    public static function set(string $type, string $message): void
    {
        $_SESSION['flash'][$type] = $message;
    }

    public static function success(string $message): void
    {
        self::set('success', $message);
    }

    public static function error(string $message): void
    {
        self::set('error', $message);
    }

    // Pobiera wszystkie komunikaty i jednocześnie je usuwa.
    // Następne wywołanie pull() zwróci pustą tablicę.
    public static function pull(): array
    {
        $messages = $_SESSION['flash'] ?? [];
        unset($_SESSION['flash']);
        return $messages;
    }
}
