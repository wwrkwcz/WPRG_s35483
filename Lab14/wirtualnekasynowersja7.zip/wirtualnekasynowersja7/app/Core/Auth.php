<?php

declare(strict_types=1);

namespace App\Core;

use App\Models\User;

/**
 * Zarządza stanem zalogowania i uprawnieniami.
 * ID zalogowanego użytkownika trzymam w sesji — to standardowe podejście.
 * Dane samego usera są cachowane w statycznej zmiennej, żeby nie robić
 * wielokrotnych zapytań do bazy w trakcie jednego żądania.
 */
class Auth
{
    private const SESSION_KEY = 'user_id';

    public static function login(array $user): void
    {
        // Regeneruję ID sesji po zalogowaniu, żeby zapobiec session fixation.
        session_regenerate_id(true);
        $_SESSION[self::SESSION_KEY] = $user['id'];
    }

    public static function logout(): void
    {
        $_SESSION = [];
        session_destroy();
    }

    public static function check(): bool
    {
        return isset($_SESSION[self::SESSION_KEY]);
    }

    public static function id(): ?int
    {
        return $_SESSION[self::SESSION_KEY] ?? null;
    }

    public static function user(): ?array
    {
        static $cached = null;
        static $fetched = false;
        if (!self::check()) {
            return null;
        }
        if (!$fetched) {
            $cached  = (new User())->find((int) self::id());
            $fetched = true;
        }
        return $cached;
    }

    public static function isAdmin(): bool
    {
        $user = self::user();
        return $user !== null && $user['role'] === 'admin';
    }

    // Przekierowanie na stronę logowania, jeśli użytkownik nie jest zalogowany.
    public static function requireLogin(): void
    {
        if (!self::check()) {
            header('Location: ' . base_url('login.php'));
            exit;
        }
    }

    // Dla stron panelu admina — sprawdzam zarówno zalogowanie, jak i rolę.
    // Jeśli ktoś nie jest adminem, dostaję 404 zamiast 403, żeby nie zdradzać
    // istnienia chronionych podstron.
    public static function requireAdmin(): void
    {
        self::requireLogin();
        if (!self::isAdmin()) {
            abort404();
        }
    }
}
