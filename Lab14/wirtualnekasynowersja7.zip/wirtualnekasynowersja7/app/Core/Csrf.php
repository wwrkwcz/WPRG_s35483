<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Ochrona formularzy przed atakami CSRF.
 *
 * Przy pierwszym wywołaniu token() generuję losowy token i zapisuję go w sesji.
 * Metoda field() wstawia go jako ukryte pole formularza.
 * Przy obsłudze żądania POST wywołuję verify() — jeśli token się nie zgadza,
 * odrzucam żądanie. Używam hash_equals() zamiast === żeby zapobiec
 * timing attack przy porównywaniu stringów.
 */
class Csrf
{
    public static function token(): string
    {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    public static function field(): string
    {
        return '<input type="hidden" name="csrf_token" value="' . e(self::token()) . '">';
    }

    public static function verify(?string $token): bool
    {
        return is_string($token) && !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
}
