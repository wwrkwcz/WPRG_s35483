<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Wylicza parametry potrzebne do stronicowania listy rekordów.
 * Przyjmuje łączną liczbę wyników, rozmiar strony i numer bieżącej strony,
 * a udostępnia gotowy offset do zapytania SQL oraz flagi hasPrevious/hasNext
 * potrzebne do renderowania przycisków nawigacji.
 */
class Paginator
{
    public int $page;
    public int $perPage;
    public int $total;
    public int $totalPages;

    public function __construct(int $total, int $perPage = 10, int $page = 1)
    {
        $this->total      = max(0, $total);
        $this->perPage    = max(1, $perPage);
        $this->totalPages = max(1, (int) ceil($this->total / $this->perPage));
        // Pilnuję, żeby numer strony z URL nie wychodził poza zakres.
        $this->page       = min(max(1, $page), $this->totalPages);
    }

    public function offset(): int
    {
        return ($this->page - 1) * $this->perPage;
    }

    public function hasPrevious(): bool
    {
        return $this->page > 1;
    }

    public function hasNext(): bool
    {
        return $this->page < $this->totalPages;
    }
}
