<?php

declare(strict_types=1);

require __DIR__ . '/../app/bootstrap.php';

use App\Core\Auth;
use App\Models\Bet;
use App\Models\Promotion;
use App\Models\User;

Auth::requireAdmin();

$userModel = new User();
$promotionModel = new Promotion();
$betModel = new Bet();

$usersCount = $userModel->count();
$promoSummary = $promotionModel->summary([]);

$dateTo = date('Y-m-d');
$dateFrom = date('Y-m-d', strtotime('-30 days'));
$totals = $betModel->totals($dateFrom, $dateTo);

$pageTitle = 'Panel administratora';
require BASE_PATH . '/views/layout/header.php';
require BASE_PATH . '/views/admin/dashboard.php';
require BASE_PATH . '/views/layout/footer.php';
