<?php

declare(strict_types=1);

require __DIR__ . '/../app/bootstrap.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Flash;
use App\Models\Promotion;
use App\Services\FileUploadService;

Auth::requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    abort404();
}

if (!Csrf::verify($_POST['csrf_token'] ?? null)) {
    Flash::error('Sesja wygasła, spróbuj ponownie.');
    header('Location: ' . base_url('admin/promotions.php'));
    exit;
}

$id = (int) ($_POST['id'] ?? 0);
$promotionModel = new Promotion();
$promotion = $promotionModel->find($id);

if ($promotion === null) {
    Flash::error('Promocja nie została znaleziona.');
} else {
    $uploader = new FileUploadService(BASE_PATH . '/public/uploads', (int) $GLOBALS['config']['max_upload_size']);
    $uploader->delete($promotion['image_path']);
    $promotionModel->delete($id);
    Flash::success('Promocja „' . $promotion['title'] . '” oraz powiązany z nią obraz zostały usunięte.');
}

header('Location: ' . base_url('admin/promotions.php'));
exit;
