<?php

declare(strict_types=1);

require __DIR__ . '/../app/bootstrap.php';

use App\Core\Auth;
use App\Models\Promotion;
use App\Services\CsvExporter;

Auth::requireAdmin();

$filters = [
    'q'         => trim((string) ($_GET['q'] ?? '')),
    'status'    => (string) ($_GET['status'] ?? ''),
    'date_from' => (string) ($_GET['date_from'] ?? ''),
    'date_to'   => (string) ($_GET['date_to'] ?? ''),
    'bonus_min' => (string) ($_GET['bonus_min'] ?? ''),
    'bonus_max' => (string) ($_GET['bonus_max'] ?? ''),
    'sort'      => (string) ($_GET['sort'] ?? 'created_at'),
    'dir'       => (string) ($_GET['dir'] ?? 'desc'),
];

$promotionModel = new Promotion();
$rows = $promotionModel->searchAll($filters);

$columns = [
    'id'            => 'ID',
    'title'         => 'Tytuł',
    'description'   => 'Opis',
    'bonus_percent' => 'Bonus (%)',
    'min_deposit'   => 'Minimalny depozyt',
    'valid_from'    => 'Ważna od',
    'valid_to'      => 'Ważna do',
    'status'        => 'Status',
    'featured'      => 'Wyróżniona',
    'created_at'    => 'Utworzono',
];

CsvExporter::stream($rows, $columns, 'promocje_' . date('Y-m-d') . '.csv');
