<?php

declare(strict_types=1);

require __DIR__ . '/../app/bootstrap.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Flash;
use App\Core\Validator;
use App\Models\Promotion;
use App\Services\FileUploadService;

Auth::requireAdmin();

$promotionModel = new Promotion();

$id = isset($_GET['id']) ? (int) $_GET['id'] : null;
$existing = null;
if ($id !== null) {
    $existing = $promotionModel->find($id);
    if ($existing === null) {
        abort404();
    }
}

$old = $existing ?? [
    'title'         => '',
    'description'   => '',
    'bonus_percent' => '10',
    'min_deposit'   => '0',
    'valid_from'    => date('Y-m-d'),
    'valid_to'      => date('Y-m-d', strtotime('+30 days')),
    'status'        => 'active',
    'featured'      => 0,
    'image_path'    => null,
];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::verify($_POST['csrf_token'] ?? null)) {
        Flash::error('Sesja wygasła, spróbuj wysłać formularz ponownie.');
        header('Location: ' . base_url('admin/promotion_form.php') . ($id !== null ? '?id=' . $id : ''));
        exit;
    }

    $old = [
        'title'         => trim((string) ($_POST['title'] ?? '')),
        'description'   => trim((string) ($_POST['description'] ?? '')),
        'bonus_percent' => (string) ($_POST['bonus_percent'] ?? ''),
        'min_deposit'   => (string) ($_POST['min_deposit'] ?? ''),
        'valid_from'    => (string) ($_POST['valid_from'] ?? ''),
        'valid_to'      => (string) ($_POST['valid_to'] ?? ''),
        'status'        => (string) ($_POST['status'] ?? 'active'),
        'featured'      => isset($_POST['featured']) ? 1 : 0,
        'image_path'    => $existing !== null ? $existing['image_path'] : null,
    ];

    $validator = new Validator($_POST);
    $validator->required('title', 'Tytuł')->maxLength('title', 150, 'Tytuł');
    $validator->required('description', 'Opis');
    $validator->required('bonus_percent', 'Bonus (%)')->numeric('bonus_percent', 'Bonus (%)')->range('bonus_percent', 0, 100, 'Bonus (%)');
    $validator->required('min_deposit', 'Minimalny depozyt')->numeric('min_deposit', 'Minimalny depozyt')->range('min_deposit', 0, 100000, 'Minimalny depozyt');
    $validator->required('valid_from', 'Data początku')->date('valid_from', 'Data początku');
    $validator->required('valid_to', 'Data końca')->date('valid_to', 'Data końca');
    $validator->dateAfterOrEqual('valid_to', 'valid_from', 'Data końca');
    $validator->in('status', ['active', 'inactive'], 'Status');
    $errors = $validator->errors();

    $uploader = new FileUploadService(BASE_PATH . '/public/uploads', (int) $GLOBALS['config']['max_upload_size']);
    $newImagePath = $old['image_path'];
    if (empty($errors)) {
        [$ok, $pathOrError] = $uploader->handle($_FILES['image'] ?? []);
        if (!$ok) {
            $errors['image'] = $pathOrError;
        } elseif ($pathOrError !== null) {
            $newImagePath = $pathOrError;
        }
    }

    if (empty($errors)) {
        $data = [
            'title'         => $old['title'],
            'description'   => $old['description'],
            'bonus_percent' => (int) $old['bonus_percent'],
            'min_deposit'   => (float) $old['min_deposit'],
            'valid_from'    => $old['valid_from'],
            'valid_to'      => $old['valid_to'],
            'status'        => $old['status'],
            'featured'      => $old['featured'],
            'image_path'    => $newImagePath,
        ];

        if ($id !== null) {
            
            if ($newImagePath !== $existing['image_path'] && !empty($existing['image_path'])) {
                $uploader->delete($existing['image_path']);
            }
            $promotionModel->update($id, $data);
            Flash::success('Promocja „' . $old['title'] . '” została zaktualizowana.');
        } else {
            $promotionModel->create($data);
            Flash::success('Promocja „' . $old['title'] . '” została dodana.');
        }

        header('Location: ' . base_url('admin/promotions.php'));
        exit;
    }
}

$pageTitle = $id !== null ? 'Edytuj promocję' : 'Nowa promocja';
require BASE_PATH . '/views/layout/header.php';
require BASE_PATH . '/views/admin/promotion_form.php';
require BASE_PATH . '/views/layout/footer.php';
