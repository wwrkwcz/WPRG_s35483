<?php

declare(strict_types=1);

require __DIR__ . '/../app/bootstrap.php';

use App\Core\Auth;
use App\Models\User;

Auth::requireAdmin();

$userModel = new User();
$users = $userModel->allWithActivity();

$pageTitle = 'Użytkownicy — panel administratora';
require BASE_PATH . '/views/layout/header.php';
require BASE_PATH . '/views/admin/users_list.php';
require BASE_PATH . '/views/layout/footer.php';
