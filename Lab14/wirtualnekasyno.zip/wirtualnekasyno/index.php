<?php

declare(strict_types=1);

require __DIR__ . '/app/bootstrap.php';

use App\Core\Auth;
use App\Models\Bet;
use App\Models\Promotion;

Auth::requireLogin();

$user = Auth::user();
$betModel = new Bet();
$recentBets = $betModel->recentForUser((int) $user['id'], 5);

$promotionModel = new Promotion();
$activePromotions = array_slice($promotionModel->allActive(), 0, 3);

$pageTitle = 'Start';
require BASE_PATH . '/views/layout/header.php';
require BASE_PATH . '/views/home/dashboard.php';
require BASE_PATH . '/views/layout/footer.php';
