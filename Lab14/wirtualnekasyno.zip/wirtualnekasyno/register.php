<?php

declare(strict_types=1);

require __DIR__ . '/app/bootstrap.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Flash;
use App\Core\Validator;
use App\Models\User;

if (Auth::check()) {
    header('Location: ' . base_url('index.php'));
    exit;
}

$errors = [];
$old = ['name' => '', 'surname' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::verify($_POST['csrf_token'] ?? null)) {
        Flash::error('Sesja wygasła, spróbuj wysłać formularz ponownie.');
        header('Location: ' . base_url('register.php'));
        exit;
    }

    $old = [
        'name'    => trim((string) ($_POST['name'] ?? '')),
        'surname' => trim((string) ($_POST['surname'] ?? '')),
        'email'   => trim((string) ($_POST['email'] ?? '')),
    ];

    $validator = new Validator($_POST);
    $validator->required('name', 'Imię')->maxLength('name', 100, 'Imię');
    $validator->required('surname', 'Nazwisko')->maxLength('surname', 100, 'Nazwisko');
    $validator->required('email', 'E-mail')->email('email', 'E-mail')->maxLength('email', 150, 'E-mail');
    $validator->required('password', 'Hasło')->minLength('password', 8, 'Hasło');
    $validator->matches('password_confirm', 'password', 'Powtórzenie hasła');

    $userModel = new User();
    $errors = $validator->errors();

    if (!$validator->fails() && $userModel->emailExists($old['email'])) {
        $errors['email'] = 'Konto z tym adresem e-mail już istnieje.';
    }

    if (empty($errors)) {
        $userId = $userModel->create(
            $old['name'],
            $old['surname'],
            $old['email'],
            (string) $_POST['password'],
            (float) $GLOBALS['config']['starting_balance']
        );
        
        
        
        $newUser = $userModel->find($userId) ?? [
            'id'      => $userId,
            'name'    => $old['name'],
            'surname' => $old['surname'],
            'email'   => $old['email'],
            'role'    => 'user',
            'balance' => (float) $GLOBALS['config']['starting_balance'],
            'theme'   => 'dark',
        ];
        Auth::login($newUser);
        Flash::success('Witaj w kasynie, ' . $old['name'] . '! Na start otrzymujesz ' . money((float) $GLOBALS['config']['starting_balance']) . '.');
        header('Location: ' . base_url('index.php'));
        exit;
    }
}

$pageTitle = 'Rejestracja';
require BASE_PATH . '/views/layout/header.php';
require BASE_PATH . '/views/auth/register.php';
require BASE_PATH . '/views/layout/footer.php';
