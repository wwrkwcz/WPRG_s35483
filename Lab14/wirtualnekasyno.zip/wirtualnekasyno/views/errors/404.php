<?php

$base = function_exists('base_url') ? base_url('') : '/';
?>
<!doctype html>
<html lang="pl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>404 — nie znaleziono</title>
<link rel="stylesheet" href="<?= htmlspecialchars(rtrim($base, '/') . '/public/css/style.css', ENT_QUOTES) ?>">
</head>
<body>
<main class="page">
  <div class="container">
    <div class="empty-state card" style="max-width:520px;margin:60px auto;text-align:center;">
      <h1 style="color:var(--accent-soft);font-size:3rem;margin-bottom:4px;">404</h1>
      <p class="lead" style="margin:0 auto 18px;">Szukany zasób nie został znaleziony. Mógł zostać usunięty albo adres jest niepoprawny.</p>
      <a class="btn btn-primary" href="<?= htmlspecialchars(rtrim($base, '/') . '/index.php', ENT_QUOTES) ?>">Wróć do strony głównej</a>
    </div>
  </div>
</main>
</body>
</html>
