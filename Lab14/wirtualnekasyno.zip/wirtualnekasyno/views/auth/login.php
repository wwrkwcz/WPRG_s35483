<?php
use App\Core\Csrf;
?>
<div class="auth-shell">
  <div class="card">
    <div class="page-header">
      <span class="eyebrow">Witaj ponownie</span>
      <h1>Zaloguj się</h1>
      <p class="lead">Wprowadź swoje dane, aby kontynuować rozgrywkę.</p>
    </div>

    <form method="post" action="<?= base_url('login.php') ?>" novalidate>
      <?= Csrf::field() ?>

      <div class="form-group">
        <label for="email">Adres e-mail</label>
        <input type="email" id="email" name="email" value="<?= e($old['email']) ?>" class="<?= isset($errors['email']) ? 'is-invalid' : '' ?>" required>
        <?php if (isset($errors['email'])): ?><div class="field-error"><?= e($errors['email']) ?></div><?php endif; ?>
      </div>

      <div class="form-group">
        <label for="password">Hasło</label>
        <input type="password" id="password" name="password" class="<?= isset($errors['password']) ? 'is-invalid' : '' ?>" required>
        <?php if (isset($errors['password'])): ?><div class="field-error"><?= e($errors['password']) ?></div><?php endif; ?>
      </div>

      <button type="submit" class="btn btn-primary btn-block">Zaloguj się</button>
    </form>

    <p class="hint" style="margin-top:16px;text-align:center;">
      Nie masz konta? <a href="<?= base_url('register.php') ?>">Zarejestruj się</a>
    </p>
  </div>
</div>
