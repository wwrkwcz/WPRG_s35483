<?php
use App\Core\Csrf;
?>
<div class="auth-shell">
  <div class="card">
    <div class="page-header">
      <span class="eyebrow">Dołącz do gry</span>
      <h1>Załóż konto</h1>
      <p class="lead">Rejestracja zajmuje chwilę. Na start otrzymasz wirtualne środki do gry.</p>
    </div>

    <form method="post" action="<?= base_url('register.php') ?>" novalidate>
      <?= Csrf::field() ?>

      <div class="grid grid-2">
        <div class="form-group">
          <label for="name">Imię</label>
          <input type="text" id="name" name="name" value="<?= e($old['name']) ?>" class="<?= isset($errors['name']) ? 'is-invalid' : '' ?>" required>
          <?php if (isset($errors['name'])): ?><div class="field-error"><?= e($errors['name']) ?></div><?php endif; ?>
        </div>
        <div class="form-group">
          <label for="surname">Nazwisko</label>
          <input type="text" id="surname" name="surname" value="<?= e($old['surname']) ?>" class="<?= isset($errors['surname']) ? 'is-invalid' : '' ?>" required>
          <?php if (isset($errors['surname'])): ?><div class="field-error"><?= e($errors['surname']) ?></div><?php endif; ?>
        </div>
      </div>

      <div class="form-group">
        <label for="email">Adres e-mail</label>
        <input type="email" id="email" name="email" value="<?= e($old['email']) ?>" class="<?= isset($errors['email']) ? 'is-invalid' : '' ?>" required>
        <?php if (isset($errors['email'])): ?><div class="field-error"><?= e($errors['email']) ?></div><?php endif; ?>
      </div>

      <div class="grid grid-2">
        <div class="form-group">
          <label for="password">Hasło</label>
          <input type="password" id="password" name="password" class="<?= isset($errors['password']) ? 'is-invalid' : '' ?>" required>
          <div class="hint">Minimum 8 znaków.</div>
          <?php if (isset($errors['password'])): ?><div class="field-error"><?= e($errors['password']) ?></div><?php endif; ?>
        </div>
        <div class="form-group">
          <label for="password_confirm">Powtórz hasło</label>
          <input type="password" id="password_confirm" name="password_confirm" class="<?= isset($errors['password_confirm']) ? 'is-invalid' : '' ?>" required>
          <?php if (isset($errors['password_confirm'])): ?><div class="field-error"><?= e($errors['password_confirm']) ?></div><?php endif; ?>
        </div>
      </div>

      <button type="submit" class="btn btn-primary btn-block">Zarejestruj się</button>
    </form>

    <p class="hint" style="margin-top:16px;text-align:center;">
      Masz już konto? <a href="<?= base_url('login.php') ?>">Zaloguj się</a>
    </p>
  </div>
</div>
