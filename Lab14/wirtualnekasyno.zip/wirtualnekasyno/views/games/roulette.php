<?php use App\Core\Csrf; ?>
<div class="page-header">
  <span class="eyebrow">Gra</span>
  <h1>Ruletka</h1>
  <p class="lead">Postaw na konkretną liczbę (35:1), kolor (1:1) lub parzystość (1:1).<br>Twoje saldo: <strong style="color:var(--accent-soft);"><?= money((float) $user['balance']) ?></strong></p>
</div>

<div class="roulette-wrap">
  <div class="wheel-shell">
    <div class="wheel-pointer"></div>
    <div class="wheel" id="wheel"></div>
    <div class="wheel-center" id="wheel-center"><?= $lastResult ? (int) $lastResult['drawn_number'] : '?' ?></div>
  </div>
  <?php if ($lastResult): ?>
    <script>document.getElementById('wheel-center').textContent = '?';</script>
  <?php endif; ?>

  <div class="card" style="min-width:320px;max-width:420px;">
    <?php if ($lastResult): ?>
      <div id="drawing-indicator">
        <div class="card-title">🎲 Kulka się toczy...</div>
        <p class="muted">Losowanie w toku, chwila cierpliwości.</p>
        <hr class="divider">
      </div>
      <div id="result-panel" style="display:none;">
        <div class="card-title">Ostatni wynik</div>
        <p>
          Wylosowana liczba: <strong style="color:var(--accent-soft);"><?= (int) $lastResult['drawn_number'] ?></strong>
          <span class="color-dot <?= e($lastResult['drawn_color']) ?>" style="margin-left:6px;"></span>
        </p>
        <p class="muted">Twój zakład: <?= e($lastResult['bet_label']) ?> za <?= money((float) $lastResult['bet_amount']) ?></p>
        <p>
          <?php if ($lastResult['win']): ?>
            <span class="badge badge-active">Wygrana: <?= money((float) $lastResult['win_amount']) ?></span>
          <?php else: ?>
            <span class="badge badge-inactive">Przegrana</span>
          <?php endif; ?>
        </p>
        <hr class="divider">
      </div>
      <noscript><style>#drawing-indicator{display:none!important;}#result-panel{display:block!important;}</style></noscript>
    <?php endif; ?>

    <form method="post" action="<?= base_url('roulette.php') ?>" id="roulette-form" novalidate>
      <?= Csrf::field() ?>
      <div class="form-group">
        <label>Rodzaj zakładu</label>
        <div class="bet-options">
          <label><input type="radio" name="bet_type" value="number" <?= $old['bet_type'] === 'number' ? 'checked' : '' ?>> Liczba (35:1)</label>
          <label><input type="radio" name="bet_type" value="color" <?= $old['bet_type'] === 'color' ? 'checked' : '' ?>> Kolor (1:1)</label>
          <label><input type="radio" name="bet_type" value="parity" <?= $old['bet_type'] === 'parity' ? 'checked' : '' ?>> Parzystość (1:1)</label>
        </div>
        <?php if (isset($errors['bet_type'])): ?><div class="field-error"><?= e($errors['bet_type']) ?></div><?php endif; ?>
      </div>
      <div class="grid grid-3">
        <div class="form-group">
          <label for="bet_number">Liczba (0–36)</label>
          <input type="number" id="bet_number" name="bet_number" min="0" max="36" value="<?= e($old['bet_number']) ?>" class="<?= isset($errors['bet_number']) ? 'is-invalid' : '' ?>">
          <?php if (isset($errors['bet_number'])): ?><div class="field-error"><?= e($errors['bet_number']) ?></div><?php endif; ?>
        </div>
        <div class="form-group">
          <label for="bet_color">Kolor</label>
          <select id="bet_color" name="bet_color" class="<?= isset($errors['bet_color']) ? 'is-invalid' : '' ?>">
            <option value="red" <?= $old['bet_color'] === 'red' ? 'selected' : '' ?>>Czerwony</option>
            <option value="black" <?= $old['bet_color'] === 'black' ? 'selected' : '' ?>>Czarny</option>
          </select>
          <?php if (isset($errors['bet_color'])): ?><div class="field-error"><?= e($errors['bet_color']) ?></div><?php endif; ?>
        </div>
        <div class="form-group">
          <label for="bet_parity">Parzystość</label>
          <select id="bet_parity" name="bet_parity" class="<?= isset($errors['bet_parity']) ? 'is-invalid' : '' ?>">
            <option value="even" <?= $old['bet_parity'] === 'even' ? 'selected' : '' ?>>Parzyste</option>
            <option value="odd" <?= $old['bet_parity'] === 'odd' ? 'selected' : '' ?>>Nieparzyste</option>
          </select>
          <?php if (isset($errors['bet_parity'])): ?><div class="field-error"><?= e($errors['bet_parity']) ?></div><?php endif; ?>
        </div>
      </div>
      <div class="form-group">
        <label for="bet_amount">Kwota zakładu</label>
        <input type="number" id="bet_amount" name="bet_amount" min="1" step="0.01" value="<?= e($old['bet_amount']) ?>" class="<?= isset($errors['bet_amount']) ? 'is-invalid' : '' ?>">
        <?php if (isset($errors['bet_amount'])): ?><div class="field-error"><?= e($errors['bet_amount']) ?></div><?php endif; ?>
      </div>
      <button type="submit" class="btn btn-primary btn-block" id="roulette-submit">Zakręć kołem</button>
    </form>
  </div>
</div>

<script>
(function () {
  var form = document.getElementById('roulette-form');
  if (!form) return;
  function sync() {
    var type = form.querySelector('input[name="bet_type"]:checked');
    type = type ? type.value : 'color';
    form.querySelector('#bet_number').closest('.form-group').style.display = (type === 'number') ? '' : 'none';
    form.querySelector('#bet_color').closest('.form-group').style.display = (type === 'color') ? '' : 'none';
    form.querySelector('#bet_parity').closest('.form-group').style.display = (type === 'parity') ? '' : 'none';
  }
  form.querySelectorAll('input[name="bet_type"]').forEach(function (el) { el.addEventListener('change', sync); });
  sync();
})();
</script>

<?php if ($lastResult): ?>
<script>
(function () {
  var wheel = document.getElementById('wheel');
  var wheelCenter = document.getElementById('wheel-center');
  var drawingIndicator = document.getElementById('drawing-indicator');
  var resultPanel = document.getElementById('result-panel');
  var gameFlash = document.getElementById('game-flash-area');
  var submitBtn = document.getElementById('roulette-submit');
  var drawnNumber = <?= (int) $lastResult['drawn_number'] ?>;

  if (submitBtn) submitBtn.disabled = true;
  if (wheel) wheel.classList.add('spinning');

  window.setTimeout(function () {
    if (wheel) wheel.classList.remove('spinning');
    if (wheelCenter) wheelCenter.textContent = drawnNumber;
    if (drawingIndicator) drawingIndicator.style.display = 'none';
    if (resultPanel) resultPanel.style.display = '';
    if (gameFlash) gameFlash.style.display = '';
    if (submitBtn) submitBtn.disabled = false;
  }, 1900);
})();
</script>
<?php endif; ?>
