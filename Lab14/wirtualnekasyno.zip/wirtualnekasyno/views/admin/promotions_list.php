<?php
use App\Core\Csrf;

$sortLink = static function (string $column) use ($filters): string {
    $dir = ($filters['sort'] === $column && $filters['dir'] === 'asc') ? 'desc' : 'asc';
    $qs = promotionsQuery($filters, ['sort' => $column, 'dir' => $dir, 'page' => null]);
    return base_url('admin/promotions.php') . '?' . $qs;
};
$sortIndicator = static function (string $column) use ($filters): string {
    if ($filters['sort'] !== $column) {
        return '';
    }
    return $filters['dir'] === 'asc' ? ' ▲' : ' ▼';
};
?>
<div class="page-header">
  <span class="eyebrow">Administracja</span>
  <h1>Promocje</h1>
  <p class="lead">Pełne zarządzanie listą promocji: wyszukiwanie, filtrowanie, sortowanie, stronicowanie i eksport.</p>
</div>

<div class="tabs">
  <a href="<?= base_url('admin/index.php') ?>">Pulpit</a>
  <a href="<?= base_url('admin/promotions.php') ?>" class="active">Promocje</a>
  <a href="<?= base_url('admin/users.php') ?>">Użytkownicy</a>
  <a href="<?= base_url('admin/reports.php') ?>">Raporty</a>
</div>

<div class="grid grid-4">
  <div class="stat-card">
    <div class="stat-value"><?= $summary['total'] ?></div>
    <div class="stat-label">Promocje (wg filtra)</div>
  </div>
  <div class="stat-card">
    <div class="stat-value"><?= $summary['active_count'] ?></div>
    <div class="stat-label">Aktywne</div>
  </div>
  <div class="stat-card">
    <div class="stat-value"><?= $summary['avg_bonus'] ?>%</div>
    <div class="stat-label">Średni bonus</div>
  </div>
  <div class="stat-card">
    <div class="stat-value"><?= money((float) $summary['sum_min_deposit']) ?></div>
    <div class="stat-label">Suma min. depozytów</div>
  </div>
</div>

<form method="get" action="<?= base_url('admin/promotions.php') ?>" class="filter-bar" style="margin-top:24px;">
  <div class="form-group">
    <label for="q">Szukaj</label>
    <input type="search" id="q" name="q" placeholder="Tytuł lub opis..." value="<?= e($filters['q']) ?>">
  </div>
  <div class="form-group">
    <label for="status">Status</label>
    <select id="status" name="status">
      <option value="">Wszystkie</option>
      <option value="active" <?= $filters['status'] === 'active' ? 'selected' : '' ?>>Aktywna</option>
      <option value="inactive" <?= $filters['status'] === 'inactive' ? 'selected' : '' ?>>Nieaktywna</option>
    </select>
  </div>
  <div class="form-group">
    <label for="date_from">Ważna od</label>
    <input type="date" id="date_from" name="date_from" value="<?= e($filters['date_from']) ?>">
  </div>
  <div class="form-group">
    <label for="date_to">Ważna do</label>
    <input type="date" id="date_to" name="date_to" value="<?= e($filters['date_to']) ?>">
  </div>
  <div class="form-group">
    <label for="bonus_min">Bonus min. %</label>
    <input type="number" id="bonus_min" name="bonus_min" min="0" max="100" value="<?= e($filters['bonus_min']) ?>">
  </div>
  <div class="form-group">
    <label for="bonus_max">Bonus maks. %</label>
    <input type="number" id="bonus_max" name="bonus_max" min="0" max="100" value="<?= e($filters['bonus_max']) ?>">
  </div>
  <div class="form-actions">
    <button type="submit" class="btn btn-primary">Filtruj</button>
    <a href="<?= base_url('admin/promotions.php') ?>" class="btn btn-secondary">Wyczyść</a>
  </div>
</form>

<div class="form-actions" style="margin-bottom:16px;justify-content:space-between;display:flex;">
  <a href="<?= base_url('admin/promotion_form.php') ?>" class="btn btn-success">+ Nowa promocja</a>
  <a href="<?= e(base_url('admin/promotion_export.php') . '?' . promotionsQuery($filters, ['page' => null])) ?>" class="btn btn-secondary">⬇ Eksportuj CSV</a>
</div>

<?php if (empty($promotions)): ?>
  <div class="empty-state card">Nie znaleziono promocji spełniających podane kryteria.</div>
<?php else: ?>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Obraz</th>
          <th><a href="<?= e($sortLink('title')) ?>">Tytuł<?= $sortIndicator('title') ?></a></th>
          <th><a href="<?= e($sortLink('bonus_percent')) ?>">Bonus<?= $sortIndicator('bonus_percent') ?></a></th>
          <th>Min. depozyt</th>
          <th><a href="<?= e($sortLink('valid_from')) ?>">Od<?= $sortIndicator('valid_from') ?></a></th>
          <th><a href="<?= e($sortLink('valid_to')) ?>">Do<?= $sortIndicator('valid_to') ?></a></th>
          <th>Status</th>
          <th>Uczestnicy</th>
          <th class="text-right">Akcje</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($promotions as $promo): ?>
        <tr>
          <td>
            <?php if (!empty($promo['image_path'])): ?>
              <img class="thumb" src="<?= e(base_url($promo['image_path'])) ?>" alt="">
            <?php else: ?>
              <span class="muted">—</span>
            <?php endif; ?>
          </td>
          <td><?= e($promo['title']) ?><?php if ($promo['featured']): ?> <span class="badge badge-admin">wyróżniona</span><?php endif; ?></td>
          <td>+<?= (int) $promo['bonus_percent'] ?>%</td>
          <td><?= money((float) $promo['min_deposit']) ?></td>
          <td><?= e(date('d.m.Y', strtotime($promo['valid_from']))) ?></td>
          <td><?= e(date('d.m.Y', strtotime($promo['valid_to']))) ?></td>
          <td><span class="badge <?= $promo['status'] === 'active' ? 'badge-active' : 'badge-inactive' ?>"><?= $promo['status'] === 'active' ? 'Aktywna' : 'Nieaktywna' ?></span></td>
          <td><?= (int) ($participantCounts[(int) $promo['id']] ?? 0) ?></td>
          <td class="text-right">
            <div class="row-actions" style="justify-content:flex-end;">
              <a class="btn btn-secondary btn-sm" href="<?= base_url('admin/promotion_form.php') ?>?id=<?= (int) $promo['id'] ?>">Edytuj</a>
              <form method="post" action="<?= base_url('admin/promotion_delete.php') ?>" onsubmit="return confirm('Usunąć tę promocję? Tej operacji nie można odwrócić.');">
                <?= Csrf::field() ?>
                <input type="hidden" name="id" value="<?= (int) $promo['id'] ?>">
                <button type="submit" class="btn btn-danger btn-sm">Usuń</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <div class="pagination">
    <?php if ($paginator->hasPrevious()): ?>
      <a href="<?= e('?' . promotionsQuery($filters, ['page' => $paginator->page - 1])) ?>">‹ Poprzednia</a>
    <?php endif; ?>
    <?php for ($p = 1; $p <= $paginator->totalPages; $p++): ?>
      <?php if ($p === $paginator->page): ?>
        <span class="current"><?= $p ?></span>
      <?php else: ?>
        <a href="<?= e('?' . promotionsQuery($filters, ['page' => $p])) ?>"><?= $p ?></a>
      <?php endif; ?>
    <?php endfor; ?>
    <?php if ($paginator->hasNext()): ?>
      <a href="<?= e('?' . promotionsQuery($filters, ['page' => $paginator->page + 1])) ?>">Następna ›</a>
    <?php endif; ?>
  </div>
<?php endif; ?>
