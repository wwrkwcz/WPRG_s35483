<?php use App\Core\Csrf; ?>
<div class="page-header">
  <span class="eyebrow">Administracja</span>
  <h1><?= $id !== null ? 'Edytuj promocję' : 'Nowa promocja' ?></h1>
  <p class="lead">Pola oznaczone jako wymagane są walidowane po stronie serwera.</p>
</div>

<div class="card" style="max-width:720px;">
  <form method="post" action="<?= base_url('admin/promotion_form.php') . ($id !== null ? '?id=' . $id : '') ?>" enctype="multipart/form-data" novalidate>
    <?= Csrf::field() ?>

    <div class="form-group">
      <label for="title">Tytuł</label>
      <input type="text" id="title" name="title" value="<?= e($old['title']) ?>" class="<?= isset($errors['title']) ? 'is-invalid' : '' ?>" required>
      <?php if (isset($errors['title'])): ?><div class="field-error"><?= e($errors['title']) ?></div><?php endif; ?>
    </div>

    <div class="form-group">
      <label for="description">Opis</label>
      <textarea id="description" name="description" class="<?= isset($errors['description']) ? 'is-invalid' : '' ?>" required><?= e($old['description']) ?></textarea>
      <?php if (isset($errors['description'])): ?><div class="field-error"><?= e($errors['description']) ?></div><?php endif; ?>
    </div>

    <div class="grid grid-2">
      <div class="form-group">
        <label for="bonus_percent">Bonus (%)</label>
        <input type="number" id="bonus_percent" name="bonus_percent" min="0" max="100" value="<?= e((string) $old['bonus_percent']) ?>" class="<?= isset($errors['bonus_percent']) ? 'is-invalid' : '' ?>" required>
        <?php if (isset($errors['bonus_percent'])): ?><div class="field-error"><?= e($errors['bonus_percent']) ?></div><?php endif; ?>
      </div>
      <div class="form-group">
        <label for="min_deposit">Minimalny depozyt</label>
        <input type="number" id="min_deposit" name="min_deposit" min="0" step="0.01" value="<?= e((string) $old['min_deposit']) ?>" class="<?= isset($errors['min_deposit']) ? 'is-invalid' : '' ?>" required>
        <?php if (isset($errors['min_deposit'])): ?><div class="field-error"><?= e($errors['min_deposit']) ?></div><?php endif; ?>
      </div>
    </div>

    <div class="grid grid-2">
      <div class="form-group">
        <label for="valid_from">Ważna od</label>
        <input type="date" id="valid_from" name="valid_from" value="<?= e((string) $old['valid_from']) ?>" class="<?= isset($errors['valid_from']) ? 'is-invalid' : '' ?>" required>
        <?php if (isset($errors['valid_from'])): ?><div class="field-error"><?= e($errors['valid_from']) ?></div><?php endif; ?>
      </div>
      <div class="form-group">
        <label for="valid_to">Ważna do</label>
        <input type="date" id="valid_to" name="valid_to" value="<?= e((string) $old['valid_to']) ?>" class="<?= isset($errors['valid_to']) ? 'is-invalid' : '' ?>" required>
        <?php if (isset($errors['valid_to'])): ?><div class="field-error"><?= e($errors['valid_to']) ?></div><?php endif; ?>
      </div>
    </div>

    <div class="grid grid-2">
      <div class="form-group">
        <label for="status">Status</label>
        <select id="status" name="status" class="<?= isset($errors['status']) ? 'is-invalid' : '' ?>">
          <option value="active" <?= $old['status'] === 'active' ? 'selected' : '' ?>>Aktywna</option>
          <option value="inactive" <?= $old['status'] === 'inactive' ? 'selected' : '' ?>>Nieaktywna</option>
        </select>
        <?php if (isset($errors['status'])): ?><div class="field-error"><?= e($errors['status']) ?></div><?php endif; ?>
      </div>
      <div class="form-group">
        <label>Wyróżniona</label>
        <div class="checkbox-row">
          <input type="checkbox" id="featured" name="featured" value="1" <?= !empty($old['featured']) ? 'checked' : '' ?>>
          <label for="featured" style="margin:0;font-weight:500;">Pokaż jako wyróżnioną na liście promocji</label>
        </div>
      </div>
    </div>

    <div class="form-group">
      <label for="image">Obraz promocji (JPG/PNG/WEBP, maks. 2 MB)</label>
      <?php if (!empty($old['image_path'])): ?>
        <div style="margin-bottom:8px;"><img class="thumb" style="width:96px;height:72px;" src="<?= e(base_url($old['image_path'])) ?>" alt=""></div>
      <?php endif; ?>
      <input type="file" id="image" name="image" accept="image/jpeg,image/png,image/webp" class="<?= isset($errors['image']) ? 'is-invalid' : '' ?>">
      <div class="hint">Pole opcjonalne. <?= $id !== null ? 'Prześlij nowy plik, aby zastąpić obecny obraz.' : '' ?></div>
      <?php if (isset($errors['image'])): ?><div class="field-error"><?= e($errors['image']) ?></div><?php endif; ?>
    </div>

    <div class="form-actions">
      <button type="submit" class="btn btn-primary"><?= $id !== null ? 'Zapisz zmiany' : 'Dodaj promocję' ?></button>
      <a href="<?= base_url('admin/promotions.php') ?>" class="btn btn-secondary">Anuluj</a>
    </div>
  </form>
</div>
