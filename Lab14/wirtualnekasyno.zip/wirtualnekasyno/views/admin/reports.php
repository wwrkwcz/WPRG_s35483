<div class="page-header">
  <span class="eyebrow">Administracja</span>
  <h1>Raporty</h1>
  <p class="lead">Statystyki gier, przychód kasyna oraz aktywność rejestracji w wybranym zakresie dat.</p>
</div>

<div class="tabs">
  <a href="<?= base_url('admin/index.php') ?>">Pulpit</a>
  <a href="<?= base_url('admin/promotions.php') ?>">Promocje</a>
  <a href="<?= base_url('admin/users.php') ?>">Użytkownicy</a>
  <a href="<?= base_url('admin/reports.php') ?>" class="active">Raporty</a>
</div>

<form method="get" action="<?= base_url('admin/reports.php') ?>" class="filter-bar">
  <div class="form-group">
    <label for="date_from">Data początku</label>
    <input type="date" id="date_from" name="date_from" value="<?= e($dateFrom) ?>">
  </div>
  <div class="form-group">
    <label for="date_to">Data końca</label>
    <input type="date" id="date_to" name="date_to" value="<?= e($dateTo) ?>">
  </div>
  <div class="form-actions">
    <button type="submit" class="btn btn-primary">Zastosuj zakres</button>
  </div>
</form>

<div class="grid grid-4">
  <div class="stat-card">
    <div class="stat-value"><?= (int) $totals['bets_count'] ?></div>
    <div class="stat-label">Liczba zakładów</div>
  </div>
  <div class="stat-card">
    <div class="stat-value"><?= money((float) $totals['total_wagered']) ?></div>
    <div class="stat-label">Suma obstawiona</div>
  </div>
  <div class="stat-card">
    <div class="stat-value"><?= money((float) $totals['total_won']) ?></div>
    <div class="stat-label">Suma wygrana przez graczy</div>
  </div>
  <div class="stat-card">
    <div class="stat-value" style="color:<?= (float) $totals['casino_income'] >= 0 ? 'var(--green-win)' : 'var(--red-soft)' ?>;">
      <?= money((float) $totals['casino_income']) ?>
    </div>
    <div class="stat-label">Przychód kasyna</div>
  </div>
</div>

<div class="grid grid-2" style="margin-top:24px;align-items:start;">
  <div class="card">
    <div class="card-title">Statystyki według gry</div>
    <?php if (empty($statsByGame)): ?>
      <p class="muted">Brak rozegranych zakładów w wybranym okresie.</p>
    <?php else: ?>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Gra</th><th>Zakłady</th><th>Obstawiono</th><th>Wygrano</th><th>Przychód</th></tr></thead>
          <tbody>
          <?php foreach ($statsByGame as $row): ?>
            <tr>
              <td><?= e($gameLabels[$row['game_type']] ?? $row['game_type']) ?></td>
              <td><?= (int) $row['bets_count'] ?></td>
              <td><?= money((float) $row['total_wagered']) ?></td>
              <td><?= money((float) $row['total_won']) ?></td>
              <td><?= money((float) $row['casino_income']) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="card-title">Nowe rejestracje dziennie</div>
    <?php if (empty($registrations)): ?>
      <p class="muted">Brak nowych rejestracji w wybranym okresie.</p>
    <?php else: ?>
      <div class="bar-chart">
        <?php foreach ($registrations as $row): ?>
          <div class="bar-row">
            <span class="muted"><?= e(date('d.m.Y', strtotime($row['day']))) ?></span>
            <div class="bar-track"><div class="bar-fill" style="width:<?= (int) round(((int) $row['count'] / $maxRegistrations) * 100) ?>%;"></div></div>
            <span><?= (int) $row['count'] ?> konto(a)</span>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</div>
