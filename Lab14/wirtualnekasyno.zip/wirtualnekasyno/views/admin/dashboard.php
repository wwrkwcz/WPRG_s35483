<div class="page-header">
  <span class="eyebrow">Administracja</span>
  <h1>Panel administratora</h1>
  <p class="lead">Przegląd kasyna oraz szybki dostęp do zarządzania promocjami, użytkownikami i raportami.</p>
</div>

<div class="tabs">
  <a href="<?= base_url('admin/index.php') ?>" class="active">Pulpit</a>
  <a href="<?= base_url('admin/promotions.php') ?>">Promocje</a>
  <a href="<?= base_url('admin/users.php') ?>">Użytkownicy</a>
  <a href="<?= base_url('admin/reports.php') ?>">Raporty</a>
</div>

<div class="grid grid-4">
  <div class="stat-card">
    <div class="stat-value"><?= $usersCount ?></div>
    <div class="stat-label">Zarejestrowani użytkownicy</div>
  </div>
  <div class="stat-card">
    <div class="stat-value"><?= $promoSummary['active_count'] ?> / <?= $promoSummary['total'] ?></div>
    <div class="stat-label">Aktywne promocje</div>
  </div>
  <div class="stat-card">
    <div class="stat-value"><?= (int) $totals['bets_count'] ?></div>
    <div class="stat-label">Zakłady (ost. 30 dni)</div>
  </div>
  <div class="stat-card">
    <div class="stat-value" style="color:<?= (float) $totals['casino_income'] >= 0 ? 'var(--green-win)' : 'var(--red-soft)' ?>;">
      <?= money((float) $totals['casino_income']) ?>
    </div>
    <div class="stat-label">Przychód kasyna (ost. 30 dni)</div>
  </div>
</div>

<div class="grid grid-3" style="margin-top:28px;">
  <a class="card tile" href="<?= base_url('admin/promotions.php') ?>" style="text-decoration:none;">
    <span class="tile-icon">🎁</span>
    <h3 style="color:var(--accent-soft);">Promocje</h3>
    <p class="muted">Pełne zarządzanie listą promocji: wyszukiwanie, filtry, sortowanie, eksport CSV.</p>
    <span class="tile-arrow">Otwórz →</span>
  </a>
  <a class="card tile" href="<?= base_url('admin/users.php') ?>" style="text-decoration:none;">
    <span class="tile-icon">👥</span>
    <h3 style="color:var(--accent-soft);">Użytkownicy</h3>
    <p class="muted">Lista kont wraz z aktywnością (liczba zakładów, suma obstawiona).</p>
    <span class="tile-arrow">Otwórz →</span>
  </a>
  <a class="card tile" href="<?= base_url('admin/reports.php') ?>" style="text-decoration:none;">
    <span class="tile-icon">📊</span>
    <h3 style="color:var(--accent-soft);">Raporty</h3>
    <p class="muted">Statystyki gier oraz przychodu kasyna w wybranym zakresie dat.</p>
    <span class="tile-arrow">Otwórz →</span>
  </a>
</div>
