<div class="page-header">
  <span class="eyebrow">Administracja</span>
  <h1>Użytkownicy</h1>
  <p class="lead">Lista zarejestrowanych kont wraz z podstawowymi statystykami aktywności w grze.</p>
</div>

<div class="tabs">
  <a href="<?= base_url('admin/index.php') ?>">Pulpit</a>
  <a href="<?= base_url('admin/promotions.php') ?>">Promocje</a>
  <a href="<?= base_url('admin/users.php') ?>" class="active">Użytkownicy</a>
  <a href="<?= base_url('admin/reports.php') ?>">Raporty</a>
</div>

<?php if (empty($users)): ?>
  <div class="empty-state card">Brak zarejestrowanych użytkowników.</div>
<?php else: ?>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Imię i nazwisko</th>
          <th>E-mail</th>
          <th>Rola</th>
          <th>Saldo</th>
          <th>Liczba zakładów</th>
          <th>Suma obstawiona</th>
          <th>Ostatnia aktywność</th>
          <th>Data rejestracji</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($users as $u): ?>
        <tr>
          <td><?= e($u['name'] . ' ' . $u['surname']) ?></td>
          <td><?= e($u['email']) ?></td>
          <td><span class="badge <?= $u['role'] === 'admin' ? 'badge-admin' : 'badge-user' ?>"><?= $u['role'] === 'admin' ? 'Administrator' : 'Użytkownik' ?></span></td>
          <td><?= money((float) $u['balance']) ?></td>
          <td><?= (int) $u['bets_count'] ?></td>
          <td><?= money((float) $u['total_wagered']) ?></td>
          <td class="muted"><?= $u['last_activity'] ? e(date('d.m.Y H:i', strtotime($u['last_activity']))) : '—' ?></td>
          <td class="muted"><?= e(date('d.m.Y', strtotime($u['created_at']))) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>
