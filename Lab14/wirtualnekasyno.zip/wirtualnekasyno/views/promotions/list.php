<?php use App\Core\Csrf; ?>
<div class="page-header">
  <span class="eyebrow">Program lojalnościowy</span>
  <h1>Aktualne promocje</h1>
  <p class="lead">Przystąp do promocji, aby skorzystać z bonusu do depozytu.</p>
</div>

<?php if (empty($activePromotions)): ?>
  <div class="empty-state card">Obecnie nie ma żadnych aktywnych promocji. Wróć tu wkrótce!</div>
<?php else: ?>
  <div class="grid grid-3">
    <?php foreach ($activePromotions as $promo): ?>
      <?php $joined = in_array((int) $promo['id'], $joinedIds, true); ?>
      <div class="card promo-card">
        <?php if (!empty($promo['image_path'])): ?>
          <img src="<?= e(base_url($promo['image_path'])) ?>" alt="<?= e($promo['title']) ?>">
        <?php endif; ?>
        <span class="badge badge-active promo-badge">+<?= (int) $promo['bonus_percent'] ?>% bonusu</span>
        <h3 style="margin-bottom:6px;"><?= e($promo['title']) ?></h3>
        <p class="muted" style="font-size:.9rem;"><?= e($promo['description']) ?></p>
        <p class="hint">Minimalny depozyt: <?= money((float) $promo['min_deposit']) ?> · ważna do <?= e(date('d.m.Y', strtotime($promo['valid_to']))) ?></p>
        <div class="promo-footer">
          <?php if ($joined): ?>
            <span class="badge badge-admin">Dołączono</span>
          <?php else: ?>
            <form method="post" action="<?= base_url('promotions.php') ?>">
              <?= Csrf::field() ?>
              <input type="hidden" name="promotion_id" value="<?= (int) $promo['id'] ?>">
              <button type="submit" class="btn btn-primary btn-sm">Dołącz</button>
            </form>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>
