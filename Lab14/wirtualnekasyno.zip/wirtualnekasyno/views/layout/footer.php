  </div>
</main>
<footer class="footer">
  <div>Konto gracza: gracz@kasyno.pl / gracz123</div>
  <div>Konto administratora: admin@kasyno.pl / admin123</div>
</footer>
</body>
</html>
