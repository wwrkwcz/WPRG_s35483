<?php

declare(strict_types=1);

require __DIR__ . '/app/bootstrap.php';

use App\Core\Auth;

Auth::logout();
header('Location: ' . base_url('login.php'));
exit;
