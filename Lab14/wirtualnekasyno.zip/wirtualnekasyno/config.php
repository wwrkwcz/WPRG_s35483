<?php

return [
    'db' => [
        'driver'   => 'mysql',
        'host'     => '127.0.0.1',
        'port'     => '3306',
        'database' => 'kasyno',
        'username' => 'root',
        'password' => '',
        'charset'  => 'utf8mb4',
    ],

    
    'app_name' => 'Wirtualne Kasyno',

    
    'starting_balance' => 1000.00,

    
    'max_upload_size' => 2 * 1024 * 1024, 
];
