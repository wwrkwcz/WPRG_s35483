<?php

declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '0');

define('BASE_PATH', dirname(__DIR__));

$GLOBALS['config'] = require BASE_PATH . '/config.php';

spl_autoload_register(function (string $class): void {
    if (strpos($class, 'App\\') !== 0) {
        return;
    }
    $relative = substr($class, strlen('App\\'));
    $path = BASE_PATH . '/app/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($path)) {
        require $path;
    }
});

use App\Core\Flash;

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

set_exception_handler(function (Throwable $e): void {
    error_log('[KASYNO] Nieobsłużony wyjątek: ' . $e->getMessage() . ' w ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    require BASE_PATH . '/views/errors/500.php';
    exit;
});

set_error_handler(function (int $severity, string $message, string $file, int $line): bool {
    error_log("[KASYNO] PHP error ($severity): $message w $file:$line");
    if ($severity & (E_ERROR | E_PARSE | E_CORE_ERROR | E_COMPILE_ERROR)) {
        http_response_code(500);
        require BASE_PATH . '/views/errors/500.php';
        exit;
    }
    return true;
});

function abort404(): void
{
    http_response_code(404);
    require BASE_PATH . '/views/errors/404.php';
    exit;
}

function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function money(float $value): string
{
    return number_format($value, 2, ',', ' ') . ' zł';
}

function asset(string $path): string
{
    return base_url($path);
}

function base_url(string $path = ''): string
{
    static $base = null;
    if ($base === null) {
        $script = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
        if (basename($script) === 'admin') {
            $script = dirname($script);
        }
        $base = rtrim($script, '/');
    }
    return $base . '/' . ltrim($path, '/');
}
