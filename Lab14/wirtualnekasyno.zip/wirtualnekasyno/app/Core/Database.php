<?php

declare(strict_types=1);

namespace App\Core;

use PDO;
use PDOException;

class Database
{
    private static ?Database $instance = null;
    private PDO $pdo;

    private function __construct(array $config)
    {
        $dsn = sprintf(
            '%s:host=%s;port=%s;dbname=%s;charset=%s',
            $config['driver'],
            $config['host'],
            $config['port'],
            $config['database'],
            $config['charset']
        );

        try {
            $this->pdo = new PDO($dsn, $config['username'], $config['password'], [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            
            
            throw new PDOException(
                'Nie można połączyć się z bazą danych. Sprawdź plik config.php oraz czy MySQL jest uruchomiony.',
                (int) $e->getCode()
            );
        }
    }

    
    
    public static function connection(): PDO
    {
        if (self::$instance === null) {
            $config = $GLOBALS['config']['db'];
            self::$instance = new self($config);
        }
        return self::$instance->pdo;
    }
}
