<?php

declare(strict_types=1);

namespace App\Core;

use App\Models\User;

class Auth
{
    private const SESSION_KEY = 'user_id';

    public static function login(array $user): void
    {
        
        session_regenerate_id(true);
        $_SESSION[self::SESSION_KEY] = $user['id'];
    }

    public static function logout(): void
    {
        $_SESSION = [];
        session_destroy();
    }

    public static function check(): bool
    {
        return isset($_SESSION[self::SESSION_KEY]);
    }

    public static function id(): ?int
    {
        return $_SESSION[self::SESSION_KEY] ?? null;
    }

    public static function user(): ?array
    {
        static $cached = null;
        static $fetched = false;
        if (!self::check()) {
            return null;
        }
        if (!$fetched) {
            $cached  = (new User())->find((int) self::id());
            $fetched = true;
        }
        return $cached;
    }

    public static function isAdmin(): bool
    {
        $user = self::user();
        return $user !== null && $user['role'] === 'admin';
    }

    
    public static function requireLogin(): void
    {
        if (!self::check()) {
            header('Location: ' . base_url('login.php'));
            exit;
        }
    }

    
    
    
    public static function requireAdmin(): void
    {
        self::requireLogin();
        if (!self::isAdmin()) {
            abort404();
        }
    }
}
