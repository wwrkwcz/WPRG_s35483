<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;
use PDO;

class Bet
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::connection();
    }

    
    
    public function create(int $userId, string $gameType, float $betAmount, string $betDetails, string $result, float $winAmount, float $balanceAfter): int
    {
        $stmt = $this->db->prepare(
            'INSERT INTO bets (user_id, game_type, bet_amount, bet_details, result, win_amount, balance_after)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$userId, $gameType, $betAmount, $betDetails, $result, $winAmount, $balanceAfter]);
        return (int) $this->db->lastInsertId();
    }

    
    
    public function recentForUser(int $userId, int $limit = 10): array
    {
        $stmt = $this->db->prepare('SELECT * FROM bets WHERE user_id = ? ORDER BY created_at DESC LIMIT ?');
        $stmt->bindValue(1, $userId, PDO::PARAM_INT);
        $stmt->bindValue(2, $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    
    
    public function userStats(int $userId): array
    {
        $sql = "SELECT COUNT(*) AS bets_count,
                       COALESCE(SUM(bet_amount), 0) AS total_wagered,
                       COALESCE(SUM(win_amount), 0) AS total_won,
                       COALESCE(SUM(win_amount) - SUM(bet_amount), 0) AS net_result
                FROM bets WHERE user_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$userId]);
        $row = $stmt->fetch();
        return [
            'bets_count'    => (int) $row['bets_count'],
            'total_wagered' => (float) $row['total_wagered'],
            'total_won'     => (float) $row['total_won'],
            'net_result'    => (float) $row['net_result'],
        ];
    }

    
    
    
    public function statsByGame(string $dateFrom, string $dateTo): array
    {
        $sql = "SELECT game_type,
                       COUNT(*) AS bets_count,
                       COALESCE(SUM(bet_amount), 0) AS total_wagered,
                       COALESCE(SUM(win_amount), 0) AS total_won,
                       COALESCE(SUM(bet_amount) - SUM(win_amount), 0) AS casino_income
                FROM bets
                WHERE created_at BETWEEN :from AND :to
                GROUP BY game_type";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':from' => $dateFrom . ' 00:00:00', ':to' => $dateTo . ' 23:59:59']);
        return $stmt->fetchAll();
    }

    
    public function totals(string $dateFrom, string $dateTo): array
    {
        $sql = "SELECT COUNT(*) AS bets_count,
                       COALESCE(SUM(bet_amount), 0) AS total_wagered,
                       COALESCE(SUM(win_amount), 0) AS total_won,
                       COALESCE(SUM(bet_amount) - SUM(win_amount), 0) AS casino_income
                FROM bets
                WHERE created_at BETWEEN :from AND :to";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':from' => $dateFrom . ' 00:00:00', ':to' => $dateTo . ' 23:59:59']);
        return $stmt->fetch();
    }

    
    
    
    public function registrationsByDay(string $dateFrom, string $dateTo): array
    {
        $sql = "SELECT DATE(created_at) AS day, COUNT(*) AS count
                FROM users
                WHERE created_at BETWEEN :from AND :to
                GROUP BY DATE(created_at)
                ORDER BY day ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':from' => $dateFrom . ' 00:00:00', ':to' => $dateTo . ' 23:59:59']);
        return $stmt->fetchAll();
    }
}
