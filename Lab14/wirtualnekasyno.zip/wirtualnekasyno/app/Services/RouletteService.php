<?php

declare(strict_types=1);

namespace App\Services;

class RouletteService
{
    private const RED_NUMBERS = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];

    public function colorOf(int $number): string
    {
        if ($number === 0) {
            return 'green';
        }
        return in_array($number, self::RED_NUMBERS, true) ? 'red' : 'black';
    }

    public function spin(): int
    {
        return random_int(0, 36);
    }

    
    public function resolve(string $betType, string $betValue, float $betAmount, int $drawnNumber): array
    {
        $win = false;
        $multiplier = 0;

        switch ($betType) {
            case 'number':
                $win = ((string) $drawnNumber === $betValue);
                $multiplier = 35;
                break;
            case 'color':
                $win = ($this->colorOf($drawnNumber) === $betValue);
                $multiplier = 1;
                break;
            case 'parity':
                
                if ($drawnNumber !== 0) {
                    $isEven = ($drawnNumber % 2 === 0);
                    $win = ($betValue === 'even' && $isEven) || ($betValue === 'odd' && !$isEven);
                }
                $multiplier = 1;
                break;
        }

        $winAmount = $win ? round($betAmount * ($multiplier + 1), 2) : 0.0;

        return [
            'drawn_number' => $drawnNumber,
            'drawn_color'  => $this->colorOf($drawnNumber),
            'win'          => $win,
            'win_amount'   => $winAmount,
        ];
    }
}
