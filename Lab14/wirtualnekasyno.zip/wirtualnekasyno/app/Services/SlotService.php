<?php

declare(strict_types=1);

namespace App\Services;

class SlotService
{
    
    
    private const SYMBOLS = [
        '🍒' => 40,
        '🍋' => 30,
        '🔔' => 18,
        '⭐' => 8,
        '💎' => 3,
        '7️⃣' => 1,
    ];

    
    private const TRIPLE_MULTIPLIER = [
        '🍒' => 3,
        '🍋' => 5,
        '🔔' => 10,
        '⭐' => 20,
        '💎' => 50,
        '7️⃣' => 100,
    ];

    
    private const PAIR_MULTIPLIER = 1.0;

    
    public function spinReel(): string
    {
        $total = array_sum(self::SYMBOLS);
        $roll = random_int(1, $total);
        $cumulative = 0;
        foreach (self::SYMBOLS as $symbol => $weight) {
            $cumulative += $weight;
            if ($roll <= $cumulative) {
                return $symbol;
            }
        }
        return '🍒'; 
    }

    
    public function spin(float $betAmount): array
    {
        $reels = [$this->spinReel(), $this->spinReel(), $this->spinReel()];
        $counts = array_count_values($reels);
        $maxCount = max($counts);
        $winAmount = 0.0;

        if ($maxCount === 3) {
            $symbol = array_keys($counts, 3)[0];
            $winAmount = round($betAmount * self::TRIPLE_MULTIPLIER[$symbol], 2);
        } elseif ($maxCount === 2) {
            $winAmount = round($betAmount * self::PAIR_MULTIPLIER, 2);
        }

        return [
            'reels'      => $reels,
            'win'        => $winAmount > 0,
            'win_amount' => $winAmount,
        ];
    }
}
