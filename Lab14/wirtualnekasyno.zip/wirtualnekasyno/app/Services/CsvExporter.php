<?php

declare(strict_types=1);

namespace App\Services;

class CsvExporter
{
    
    public static function stream(array $rows, array $columns, string $filename): void
    {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        $output = fopen('php://output', 'w');
        fwrite($output, "\xEF\xBB\xBF"); 
        fputcsv($output, array_values($columns), ';');

        foreach ($rows as $row) {
            $line = [];
            foreach (array_keys($columns) as $field) {
                $line[] = $row[$field] ?? '';
            }
            fputcsv($output, $line, ';');
        }

        fclose($output);
        exit;
    }
}
