<?php

declare(strict_types=1);

require __DIR__ . '/app/bootstrap.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Flash;
use App\Models\Promotion;
use App\Models\UserPromotion;

Auth::requireLogin();

$user = Auth::user();
$userPromotionModel = new UserPromotion();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::verify($_POST['csrf_token'] ?? null)) {
        Flash::error('Sesja wygasła, spróbuj ponownie.');
    } else {
        $promotionId = (int) ($_POST['promotion_id'] ?? 0);
        $promotionModel = new Promotion();
        $promotion = $promotionModel->find($promotionId);
        if ($promotion === null) {
            Flash::error('Promocja nie istnieje.');
        } elseif ($userPromotionModel->hasJoined((int) $user['id'], $promotionId)) {
            Flash::error('Już przystąpiłeś do tej promocji.');
        } else {
            $userPromotionModel->join((int) $user['id'], $promotionId);
            Flash::success('Dołączyłeś do promocji „' . $promotion['title'] . '”.');
        }
    }
    header('Location: ' . base_url('promotions.php'));
    exit;
}

$promotionModel = new Promotion();
$activePromotions = $promotionModel->allActive();
$joinedIds = $userPromotionModel->joinedPromotionIds((int) $user['id']);

$pageTitle = 'Promocje';
require BASE_PATH . '/views/layout/header.php';
require BASE_PATH . '/views/promotions/list.php';
require BASE_PATH . '/views/layout/footer.php';
