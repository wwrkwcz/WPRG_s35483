<?php

declare(strict_types=1);

require __DIR__ . '/app/bootstrap.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Flash;
use App\Models\Bet;
use App\Models\Promotion;
use App\Models\User;
use App\Models\UserPromotion;

Auth::requireLogin();

$userId = (int) Auth::id();
$userModel = new User();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::verify($_POST['csrf_token'] ?? null)) {
        Flash::error('Sesja wygasła, spróbuj ponownie.');
    } else {
        $theme = (string) ($_POST['theme'] ?? 'dark');
        if (in_array($theme, ['light', 'dark'], true)) {
            $userModel->updateTheme($userId, $theme);
            Flash::success('Preferencje zostały zapisane.');
        }
    }
    header('Location: ' . base_url('account.php'));
    exit;
}

$user = $userModel->find($userId);

$betModel = new Bet();
$stats = $betModel->userStats($userId);
$recentBets = $betModel->recentForUser($userId, 15);

$userPromotionModel = new UserPromotion();
$joinedIds = $userPromotionModel->joinedPromotionIds($userId);
$promotionModel = new Promotion();
$joinedPromotions = [];
foreach ($joinedIds as $pid) {
    $promo = $promotionModel->find($pid);
    if ($promo !== null) {
        $joinedPromotions[] = $promo;
    }
}

$pageTitle = 'Moje konto';
require BASE_PATH . '/views/layout/header.php';
require BASE_PATH . '/views/account/profile.php';
require BASE_PATH . '/views/layout/footer.php';
