<?php

declare(strict_types=1);

require __DIR__ . '/app/bootstrap.php';

use App\Core\Auth;
use App\Core\Csrf;
use App\Core\Flash;
use App\Models\User;

if (Auth::check()) {
    header('Location: ' . base_url('index.php'));
    exit;
}

$errors = [];
$old = ['email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!Csrf::verify($_POST['csrf_token'] ?? null)) {
        Flash::error('Sesja wygasła, spróbuj wysłać formularz ponownie.');
        header('Location: ' . base_url('login.php'));
        exit;
    }

    $old['email'] = trim((string) ($_POST['email'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    if ($old['email'] === '') {
        $errors['email'] = 'Pole „E-mail” jest wymagane.';
    }
    if ($password === '') {
        $errors['password'] = 'Pole „Hasło” jest wymagane.';
    }

    if (empty($errors)) {
        $userModel = new User();
        $user = $userModel->findByEmail($old['email']);

        if ($user === null || !$userModel->verifyPassword($user, $password)) {
            $errors['password'] = 'Nieprawidłowy e-mail lub hasło.';
        } else {
            Auth::login($user);
            Flash::success('Witaj z powrotem, ' . $user['name'] . '!');
            header('Location: ' . base_url('index.php'));
            exit;
        }
    }
}

$pageTitle = 'Logowanie';
require BASE_PATH . '/views/layout/header.php';
require BASE_PATH . '/views/auth/login.php';
require BASE_PATH . '/views/layout/footer.php';
